/**
 * dsh-jingyu-bridge — Tinode「鱼」桥接服务 ↔ DeepSeek Harness 的双向中转插件。
 *
 * 非 DSH 官方插件，个人项目。
 *
 * 方向 A（外部 → DSH）：桥接服务 POST /inject，把一条文本作为 user/message
 * 投递进指定 DSH 会话（sessionId 由 /session/new 创建）。
 * 方向 B（DSH → 外部）：监听全局 `session/event` 的 assistant/message 事件，
 * 只抽取文本块，POST 回桥接服务的 /callback。
 *
 * 关键设计：
 *  - 以 profile 层条目（cordis.patch.yml 的 insert，name 用绝对路径）挂载，
 *    因此挂载在 profile 根上下文，listener 是全局的：任何一个会话（包括不是
 *    本插件创建的普通 Web 会话）的 assistant/message 都会被看到。
 *  - 每个 Tinode 用户一个独立会话：/session/new 每次生成一个全新 sessionId，
 *    上下文不会串。
 *  - 只监听 127.0.0.1，不暴露公网。
 *  - /session/ensure：调用方给 sessionId，按 live → resumed → created 的顺序
 *    让它可用；resume 会用与 create 完全一致的 setup（preset + 默认模型），
 *    cwd 由持久化的 session header 自动恢复，setup 不额外补。
 *
 * 单实例假设（重要）：本方案假设同一时间只有一个 DSH 进程在写 sessions 目录。
 * 多个 DSH 进程共享同一 JSONL 会话目录会互相破坏日志，需要
 * dsh-single-instance-guard 之类的保护；当前部署未安装该 guard（单实例，风险可控）。
 *
 * 依赖解析：插件目录不在 profile 的 node_modules 里，裸导入 @deepseek-ai/dsh-llm
 * 可能解析不到，因此带一层「从 dsh 安装目录 createRequire」的兜底。
 *
 * 部署：profile 条目当前指向 index.ensure.js（本文件）。Cordis 的条目热重挂载
 * 只重建实例、不重新 import 模块（Node ESM 按 URL 缓存），所以每次改代码都要用
 * 新文件名挂载；index.live.js 是上一版，保留作回滚。
 * @module dsh-jingyu-bridge
 */

import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { mkdirSync, realpathSync } from 'node:fs';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const TAG = '[dsh-jingyu-bridge]';

/**
 * Resolve one package exported by the dsh installation. The normal path is the
 * runtime's own package resolution (installation packages are supplied to the
 * ESM resolver); the fallback anchors a require at the running dsh CLI so an
 * absolute-path plugin outside the profile's node_modules still resolves it.
 */
async function importFromDsh(specifier) {
  try {
    return await import(specifier);
  } catch (firstError) {
    const anchor = realpathSync(process.argv[1] ?? process.execPath);
    const require = createRequire(anchor);
    const resolved = require.resolve(specifier);
    try {
      return await import(pathToFileURL(resolved).href);
    } catch (secondError) {
      throw new Error(
        '无法解析 ' + specifier + '：ESM 裸导入失败（' + String(firstError?.message ?? firstError) +
          '），安装目录解析也失败（' + String(secondError?.message ?? secondError) + '）',
      );
    }
  }
}

const llmModule = await importFromDsh('@deepseek-ai/dsh-llm').catch((error) => {
  console.error(TAG + ' 加载失败：' + String(error?.message ?? error));
  throw error;
});
const createUserMessage = llmModule.createUserMessage;
if (typeof createUserMessage !== 'function') {
  throw new Error(TAG + ' @deepseek-ai/dsh-llm 没有导出 createUserMessage');
}

// installModelSelection 会把默认 provider/model 注入 system-prompt 变量
// （{{provider}} / {{model}}）和每次 agent/request；缺了它，preset 里的
// "{{model}} has no value" 会让整个回合直接报错。
const { installModelSelection } = await importFromDsh('@deepseek-ai/dsh-agent').catch((error) => {
  console.error(TAG + ' 加载失败：' + String(error?.message ?? error));
  throw error;
});

export const name = 'dsh-jingyu-bridge';
export const inject = ['agents'];

const DEFAULTS = {
  host: '127.0.0.1',
  port: 8091,
  callbackUrl: 'http://127.0.0.1:8092/callback',
  /** 新会话的工作目录（每个会话都在这里，作为 cwd 记录进 session header）。 */
  workspace: '/root/fish-workspace',
  /** agent preset id；留空 = agentPresets 的默认预设。 */
  preset: '',
  /** 回调超时（毫秒）。 */
  callbackTimeoutMs: 5000,
};

const log = (...args) => console.log(TAG, ...args);
const warn = (...args) => console.error(TAG, ...args);

/** 只取 assistant message 的文本块；工具调用/推理/附件一律忽略。 */
export function extractText(message) {
  const blocks = message?.content;
  if (!Array.isArray(blocks)) return '';
  const parts = [];
  for (const block of blocks) {
    if (block !== null && typeof block === 'object' && block.type === 'text' && typeof block.text === 'string') {
      parts.push(block.text);
    }
  }
  return parts.join('');
}

/** 读 JSON 请求体（上限 1MiB，防止大包打爆内存）。 */
function readJson(req, limit = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(Object.assign(new Error('请求体过大'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (size === 0) return reject(Object.assign(new Error('请求体为空'), { statusCode: 400 }));
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(Object.assign(new Error('请求体不是合法 JSON'), { statusCode: 400 }));
      }
    });
    req.on('error', reject);
  });
}

/**
 * @param {import('@deepseek-ai/cordis').Context} ctx profile 根上下文
 * @param {Record<string, unknown>} [config] cordis.patch.yml 里该条目的 config
 */
export function apply(ctx, config) {
  const cfg = { ...DEFAULTS, ...(config ?? {}) };
  const host = String(cfg.host || DEFAULTS.host);
  const port = Number(cfg.port) || DEFAULTS.port;
  const callbackUrl = String(cfg.callbackUrl || DEFAULTS.callbackUrl);
  const workspace = String(cfg.workspace || DEFAULTS.workspace);
  const presetId = cfg.preset === undefined || cfg.preset === null || cfg.preset === '' ? undefined : String(cfg.preset);
  const callbackTimeoutMs = Number(cfg.callbackTimeoutMs) || DEFAULTS.callbackTimeoutMs;

  /** sessionId → AgentHandle（同时把 agent 的 owner fiber 挂在本插件下）。 */
  const sessions = new Map();
  /** 回调串行链：保证同一会话的多条 assistant/message 按序到达桥接服务。 */
  let callbackChain = Promise.resolve();
  let closed = false;

  try {
    mkdirSync(workspace, { recursive: true });
  } catch (error) {
    warn('工作目录创建失败（继续，cwd 可能被 header 记为不存在路径）：' + workspace + ' → ' + String(error?.message ?? error));
  }

  /** 让新会话加入默认（或指定）agent preset：工具、提示词、人格都来自这里。 */
  async function joinPreset(agentCtx) {
    const presets = ctx.get('agentPresets');
    if (!presets) {
      warn('agentPresets 服务不可用，跳过 preset 挂载（回退到全局层）');
      return;
    }
    try {
      const preset = await presets.mount(agentCtx, presetId);
      log('会话加入预设：' + preset.id);
    } catch (error) {
      warn('agent preset 挂载失败（回退到全局层）：' + String(error?.message ?? error));
    }
  }

  /**
   * 读部署的默认模型选择。preset 的提示词里用了 {{provider}} / {{model}}，
   * 不注入就会在第一次 assemble 时报 "prompt variable ... has no value"。
   */
  function readDefaultSelection() {
    const service = ctx.get('agentDefaultModel');
    if (!service) {
      warn('agentDefaultModel 服务不可用：新会话不会带默认模型（preset 若引用 {{model}} 会失败）');
      return undefined;
    }
    try {
      return service.currentSelection();
    } catch (error) {
      warn('读取默认模型失败：' + String(error?.message ?? error));
      return undefined;
    }
  }

  /**
   * 默认模型 + preset 装配。create 与 resume 必须用完全一致的 setup：
   * 少了 joinPreset 会丢工具/提示词，少了 installModelSelection 会撞 {{model}}。
   */
  function buildAgentWiring() {
    const selection = readDefaultSelection();
    const agentOptions = selection === undefined
      ? {}
      : { provider: selection.provider, model: selection.model };
    // dsh-agent 的 installModelSelection 约定的可变引用：assemble 后记录实际
    // 生效的 selection，agent/request 再读它。
    const selectionRef = selection === undefined ? undefined : { current: selection, assembled: undefined };
    const setup = async (agentCtx) => {
      await joinPreset(agentCtx);
      if (selectionRef !== undefined) installModelSelection(agentCtx, selectionRef);
    };
    return { agentOptions, setup };
  }

  /**
   * 官方以编程方式创建会话：ctx.agents.create()（由 dsh-agent-loop 通过
   * AgentFactory 实现，内部走 sessions.prepare + 持久化 + publish）。
   */
  async function createSession() {
    const sessionId = randomUUID();
    const { agentOptions, setup } = buildAgentWiring();

    let handle;
    try {
      handle = await ctx.agents.create({
        sessionId,
        meta: { cwd: workspace },
        agentOptions,
        setup,
      });
    } catch (error) {
      throw new Error('ctx.agents.create 失败：' + String(error?.message ?? error));
    }
    // 创建后等待 agent 进入空闲，避免首个 followup 撞上初始化中的回合。
    await handle.agent.whenIdle();
    sessions.set(sessionId, handle);
    log('已创建会话 sessionId=' + sessionId + '（当前存活 ' + sessions.size + ' 个）');
    return handle.agent.session?.id ?? sessionId;
  }

  /** 持久化错误的类型名（这些错误类都用 error.name 区分）。 */
  function errorKind(error) {
    const kind = error?.name;
    return typeof kind === 'string' && kind !== '' && kind !== 'Error' ? kind : 'unknown';
  }

  /**
   * 让调用方给定的 sessionId 变成可用 agent：live → resumed → created。
   * 只有 SessionPersistenceNotFoundError（没有落盘日志）才允许 create；
   * 日志损坏/被占用/其他错误一律返回错误，不自动清理、不改数据库。
   *
   * 注意：resume 的 cwd 由持久化的 session header 恢复（AgentLoop.resumeWith
   * 把 handle.header 作为 meta 交给 sessions.prepare），所以这里不需要补 meta。
   */
  async function ensureSession(sessionId) {
    if (ctx.agents.get(sessionId) !== undefined) {
      log('ensure: get session=' + sessionId + ' -> live');
      return { ok: true, sessionId, source: 'live' };
    }

    const { agentOptions, setup } = buildAgentWiring();

    log('ensure: resume session=' + sessionId);
    let handle;
    try {
      handle = await ctx.agents.resume({
        resumeSessionId: sessionId,
        agentOptions,
        setup,
      });
    } catch (error) {
      const kind = errorKind(error);
      const detail = String(error?.message ?? error);
      if (kind === 'SessionPersistenceNotFoundError') {
        log('ensure: create session=' + sessionId + '（resume 未找到落盘日志）');
        try {
          handle = await ctx.agents.create({
            sessionId,
            meta: { cwd: workspace },
            agentOptions,
            setup,
          });
        } catch (createError) {
          const createDetail = String(createError?.message ?? createError);
          log('ensure: error create_failed session=' + sessionId);
          return { ok: false, sessionId, error: 'create_failed', detail: createDetail };
        }
        await handle.agent.whenIdle();
        sessions.set(sessionId, handle);
        log('ensure: created session=' + sessionId);
        return { ok: true, sessionId, source: 'created' };
      }
      if (kind === 'SessionPersistenceCorruptionError' || kind === 'SessionFormatUnsupportedError') {
        log('ensure: error corrupt session=' + sessionId + '（' + kind + '）');
        return { ok: false, sessionId, error: 'corrupt', detail };
      }
      if (kind === 'SessionAlreadyOwnedError') {
        log('ensure: error owned session=' + sessionId);
        return { ok: false, sessionId, error: 'owned', detail };
      }
      log('ensure: error ' + kind + ' session=' + sessionId);
      return { ok: false, sessionId, error: kind, detail };
    }

    await handle.agent.whenIdle();
    sessions.set(sessionId, handle);
    log('ensure: resumed session=' + sessionId);
    return { ok: true, sessionId, source: 'resumed' };
  }

  /** 投递一条用户文本到指定会话；返回 false 表示该 sessionId 不在存活表里。 */
  function inject(sessionId, text) {
    // ctx.agents.get(id) 的入参就是 SessionId（Agent.id 与 Session.id 共用同一个 id）。
    const agent = ctx.agents.get(sessionId);
    if (agent === undefined) return false;
    agent.followup(
      createUserMessage({
        content: [{ type: 'text', text }],
        source: { kind: 'plugin:dsh-jingyu-bridge' },
      }),
    );
    return true;
  }

  /** 把 assistant 文本回传桥接服务；串行 + 单次尝试 + 超时，失败只记日志。 */
  function sendCallback(payload) {
    if (closed) return callbackChain;
    callbackChain = callbackChain
      .then(async () => {
        const response = await fetch(callbackUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json; charset=utf-8' },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(callbackTimeoutMs),
        });
        const body = await response.text().catch(() => '');
        if (!response.ok) {
          warn('回调被拒绝 HTTP ' + response.status + '（session=' + payload.sessionId + '）: ' + body.slice(0, 200));
        }
      })
      .catch((error) => {
        warn('回调失败（session=' + payload.sessionId + '）：' + String(error?.message ?? error));
      });
    return callbackChain;
  }

  /**
   * 全局 session/event 监听。本插件挂在 profile 根上下文，非 agent 作用域，
   * 因此所有会话（含普通 Web 会话）的 assistant/message 都会到这里。
   */
  function onSessionEvent(session, event) {
    if (event?.type !== 'assistant/message') return;
    const text = extractText(event.data?.message);
    if (text.trim() === '') return;
    void sendCallback({ sessionId: String(session.id), text });
  }

  const server = createServer(async (req, res) => {
    const reply = (status, body) => {
      const text = JSON.stringify(body);
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'content-length': Buffer.byteLength(text),
      });
      res.end(text);
    };

    let pathname = '/';
    try {
      pathname = new URL(req.url ?? '/', 'http://127.0.0.1').pathname;
    } catch {
      return reply(400, { error: '非法 URL' });
    }

    try {
      if (req.method === 'GET' && pathname === '/health') {
        return reply(200, { ok: true, sessions: sessions.size });
      }

      if (pathname === '/session/new') {
        if (req.method !== 'POST') return reply(405, { error: 'method not allowed' });
        const sessionId = await createSession();
        return reply(200, { sessionId });
      }

      if (pathname === '/session/ensure') {
        if (req.method !== 'POST') return reply(405, { error: 'method not allowed' });
        const body = await readJson(req);
        const sessionId = typeof body.sessionId === 'string' ? body.sessionId.trim() : '';
        if (sessionId === '') return reply(400, { error: 'sessionId 必填且必须是字符串' });
        const result = await ensureSession(sessionId);
        if (result.ok) return reply(200, result);
        const status = result.error === 'owned' ? 409 : result.error === 'corrupt' ? 422 : 500;
        return reply(status, result);
      }

      if (pathname === '/inject') {
        if (req.method !== 'POST') return reply(405, { error: 'method not allowed' });
        const body = await readJson(req);
        const sessionId = typeof body.sessionId === 'string' ? body.sessionId.trim() : '';
        const text = typeof body.text === 'string' ? body.text : '';
        if (sessionId === '') return reply(400, { error: 'sessionId 必填且必须是字符串' });
        if (text.trim() === '') return reply(400, { error: 'text 必填且不能为空' });
        if (!inject(sessionId, text)) {
          return reply(404, { error: 'session 不存在（没有存活的 agent）', sessionId });
        }
        log('已注入 session=' + sessionId + ' len=' + text.length);
        return reply(200, { ok: true, sessionId });
      }

      return reply(404, { error: 'not found' });
    } catch (error) {
      const status = Number(error?.statusCode) || 500;
      warn('处理 ' + pathname + ' 出错（HTTP ' + status + '）：' + String(error?.message ?? error));
      return reply(status, { error: String(error?.message ?? error) });
    }
  });

  ctx.effect(() => {
    const offSessionEvent = ctx.on('session/event', onSessionEvent);

    server.on('clientError', (error, socket) => {
      warn('HTTP 客户端错误：' + String(error?.message ?? error));
      socket.destroy();
    });
    server.on('error', (error) => {
      warn('HTTP 服务错误（端口 ' + host + ':' + port + '）：' + String(error?.message ?? error));
    });
    server.listen(port, host, () => {
      log('已挂载：监听 http://' + host + ':' + port + '（回调 ' + callbackUrl + '）');
    });

    return async () => {
      closed = true;
      offSessionEvent();
      await new Promise((resolve) => server.close(() => resolve()));
      for (const [sessionId, handle] of sessions) {
        try {
          await handle.dispose();
        } catch (error) {
          warn('释放会话失败 session=' + sessionId + '：' + String(error?.message ?? error));
        }
      }
      sessions.clear();
      log('已卸载');
    };
  }, 'dsh-jingyu-bridge.lifecycle');

  log('插件已加载（profile 级），等待 HTTP 端口就绪……');
}
