# dsh-jingyu-bridge

> **非 DSH 官方插件，个人项目。**

Tinode「鱼」桥接服务（`/root/fish-bridge/`）与 DeepSeek Harness 之间的双向中转，
替代原来的 OneBot 中转链路：

```
Tinode 用户 ──> 鱼账号 ──> fish-bridge ──POST /inject──────────> dsh-jingyu-bridge ──> DSH 会话
                                  <──POST /callback─────────── dsh-jingyu-bridge <── assistant/message
```

每个给鱼发消息的 Tinode 用户对应一个**独立的 DSH 会话**（每次 `/session/new`
生成全新 sessionId），上下文互不串。

## 文件

| 文件 | 作用 |
|---|---|
| `index.js` | 源码（唯一真源） |
| `index.ensure.js` | **当前被 profile 加载的版本**（含 `/session/ensure`） |
| `index.live.js` | 上一版部署副本，保留作回滚 |
| `package.json` | ESM 包声明（`type: module`） |
| `cordis.patch.yml` | bundle 形态的备用入口（当前不用，见文末） |

## 挂载方式（profile 级，全局生效）

`/root/.dsh/profiles/web/cordis.patch.yml` 末尾：

```yaml
- insert:
    - id: dsh-jingyu-bridge
      name: /root/dsh-plugins/dsh-jingyu-bridge/index.live.js
      config:
        host: 127.0.0.1
        port: 8091
        callbackUrl: http://127.0.0.1:8092/callback
        workspace: /root/fish-workspace
        preset: standard
        callbackTimeoutMs: 6000
```

`insert` 位于补丁层**最外层**（不在任何 group / 会话配置里），所以它是 profile 的
**根条目**：该 profile 下所有会话共享同一个插件实例，不存在「只在创建它的会话里
生效」。`dsh --profile web --dump-config` 能看到这一行与 `project-karen` 等并列。

### 为什么指向 `index.live.js` 而不是 `index.js`

Cordis 的条目热重挂载只销毁/重建插件实例，**不会重新 import 模块**（Node ESM 按
URL 缓存），所以改完代码后热重载仍跑旧版。首次挂载后想在不重启进程的情况下换代码，
只能换一个新的文件路径：`cp index.js index.live.js` 再重新挂载。

等下次 `systemctl restart dsh.service`（进程重启 = 全新模块缓存）之后，可以把
`name` 改回 `index.js` 并删除 `index.live.js`。

## 接口

只监听 `127.0.0.1:8091`，不暴露公网。

### `POST /session/new`

创建全新 DSH 会话，返回 `{"sessionId":"..."}`。

### `POST /session/ensure`

请求体 `{"sessionId":"..."}`。sessionId **由调用方传入**，插件不生成、不改写。

按 `live → resumed → created` 的顺序让这个 id 可用：

| 结果 | HTTP | body |
|---|---|---|
| 内存里已有 live agent | 200 | `{"ok":true,"sessionId":"…","source":"live"}` |
| 从 JSONL 持久化恢复成功 | 200 | `{"ok":true,"sessionId":"…","source":"resumed"}` |
| 没有落盘日志，新建成功 | 200 | `{"ok":true,"sessionId":"…","source":"created"}` |
| 日志损坏 / 版本不支持 | 422 | `{"ok":false,"sessionId":"…","error":"corrupt","detail":"…"}` |
| 写锁被占用 | 409 | `{"ok":false,"sessionId":"…","error":"owned","detail":"…"}` |
| create 失败 | 500 | `{"ok":false,"sessionId":"…","error":"create_failed","detail":"…"}` |
| 其它 | 500 | `{"ok":false,"sessionId":"…","error":"<类型或 unknown>","detail":"…"}` |

只有 `SessionPersistenceNotFoundError` 才允许回落到 create；损坏/被占用一律报错，
不自动清理日志、不改数据库。resume 的 setup 与 `createSession()` 完全一致
（`joinPreset` + `installModelSelection`），cwd 由持久化的 session header 自动恢复。

### `POST /inject`

```json
{ "sessionId": "<刚创建的>", "text": "测试" }
```

- `200 {"ok":true,"sessionId":"..."}`
- `404 {"error":"session 不存在（没有存活的 agent）","sessionId":"..."}`
- `400` 参数缺失 / 非法 JSON

实现：`ctx.agents.get(sessionId)` → `agent.followup(createUserMessage({...}))`，
`source.kind = 'plugin:dsh-jingyu-bridge'`。

### `GET /health`

`{"ok":true,"sessions":N}`，探活用。

### 回调

监听全局 `session/event`，只处理 `assistant/message`，从
`event.data.message.content` 抽 `type === 'text'` 的块拼文本（工具调用、推理、
图片/文件块全部忽略），POST 到 `callbackUrl`：

```json
{ "sessionId": "...", "text": "..." }
```

串行发送（同会话保序）、单次尝试、超时 6s，失败只写日志，不影响 DSH。

## 配置

| 字段 | 默认值 | 说明 |
|---|---|---|
| `host` | `127.0.0.1` | 监听地址，**不要改成 0.0.0.0** |
| `port` | `8091` | 监听端口 |
| `callbackUrl` | `http://127.0.0.1:8092/callback` | 回复回调地址 |
| `workspace` | `/root/fish-workspace` | 新会话 cwd（启动时 mkdir -p） |
| `preset` | `''`（默认预设） | 新会话加入的 agent preset；当前显式写 `standard` |
| `callbackTimeoutMs` | `6000` | 回调超时 |

## 查证结论

### 1. `ctx.agents.get()` 的入参是 sessionId 还是 agentId？

**是 sessionId。** DSH 里 Agent 与 Session 共用同一个 id，没有独立 agentId：

- 运行期契约：`get(id: SessionId): Agent | undefined`，文档写明是 “the shared
  agent/session id”。
- `Agent` 接口只有 `readonly id: SessionId`；`AgentHandle.agent.session.id` 同值。

所以 `ctx.agents.get(sessionId)` 就是正确用法，不存在「sessionId → agentId」的换算。
dsh-onebot-qq 也是按 session id 建索引（`bySession.get(session.id)`）。

### 2. 以编程方式创建新 session 的官方方式

**`ctx.agents.create(options)`**（`AgentFactory` 由 `@deepseek-ai/dsh-agent-loop`
实现；dsh-onebot-qq 的 `registry.js` 就是这样建会话）：

```js
const handle = await ctx.agents.create({
  sessionId,                 // 自己生成的唯一 SessionId
  meta: { cwd },             // 写进 session header
  agentOptions,              // { provider, model }，来自默认模型选择
  setup: async (agentCtx) => {
    await ctx.agentPresets.mount(agentCtx, presetId);      // 工具/提示词/人格
    installModelSelection(agentCtx, selectionRef);          // {{provider}}/{{model}}
  },
});
await handle.agent.whenIdle();
// handle.agent.session.id / handle.dispose()
```

没有「只建 session 不建 agent」的公开 API（`ctx.sessions.prepare()` 是 loop 内部
装配步骤）。已用它实现 `/session/new`，没有用 followup 硬编码到主会话绕过。

> 踩坑：preset `standard` 的 `deployment:persona-prefix` 段引用 `{{model}}`，
> 不 `installModelSelection` 时首个回合直接报
> `prompt variable "{{model}}" has no value`。插件已按上面方式注入默认模型。

## 实测验证（2026-10-31 07:42，本机）

1. profile 条目热加载成功，日志：
   `[dsh-jingyu-bridge] 已挂载：监听 http://127.0.0.1:8091`。
2. `POST /session/new` → `{"sessionId":"07f4ac33-…"}`。
3. `POST /inject`（text=`测试：请只回复一句话：收到。`）→ `{"ok":true,…}`。
4. 8092 临时抓包服务收到：
   `{"sessionId":"07f4ac33-…","text":"收到。"}`（推理块被忽略，只转文本）。
5. 跨会话：普通 Web 会话 `session-f14643cd-…` 的 assistant 文本同样被转发到 8092
   —— 插件不限于自己创建的会话。
6. `POST /inject` 传不存在的 sessionId → `404`。

## 单实例假设（重要）

本方案假设**同一时间只有一个 DSH 进程**在写 `/root/.dsh/sessions`。多个 DSH 进程共享
同一 JSONL 会话目录会互相破坏日志；要跑多进程必须先装 `dsh-single-instance-guard`
之类的保护。当前部署未安装该 guard（单实例，风险可控）。

## 已知限制

- **会话只活在进程内**：DSH 重启后 `agents.get()` 找不到旧 sessionId，`/inject` 返回
  404。桥接服务需要重新 `/session/new`（后续可选：持久化映射 + `ctx.agents.resume()`）。
- **全局监听**：所有会话（含 Web GUI）的 assistant 文本都会回调到 8092，桥接服务按
  sessionId 过滤即可。
- 会话的审批策略是 `ask`：鱼无人值守时遇到需要审批的工具会 fail-closed，后续可能
  需要给这类会话装一个自动审批策略。
- 只做文本，不处理图片/语音/群聊。
- 不要再用 `plugin_manager install_bundle` 装一遍：`cordis.patch.yml` 是 bundle 形态
  备用入口，两种方式并用会挂两份、抢 8091。
