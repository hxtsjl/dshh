/**
 * dsh-jingyu-bridge — Tinode「鱼」桥接服务 ↔ DeepSeek Harness 的双向中转插件。
 *
 * 非 DSH 官方插件，个人项目。
 *
 * 方向 A（外部 → DSH）：桥接服务 POST /inject，把一条文本作为 user/message
 * 投递进指定 DSH 会话（sessionId 由 /session/new 创建）。
 * 方向 B（DSH → 外部）：监听全局 `session/event` 的 assistant/message 事件，
 * 只抽取文本块，POST 回桥接服务的 /callback。
 *
 * 关键设计：
 *  - 以 profile 层条目（cordis.patch.yml 的 insert，name 用绝对路径）挂载，
 *    因此挂载在 profile 根上下文，listener 是全局的：任何一个会话（包括不是
 *    本插件创建的普通 Web 会话）的 assistant/message 都会被看到。
 *  - 每个 Tinode 用户一个独立会话：/session/new 每次生成一个全新 sessionId，
 *    上下文不会串。
 *  - 只监听 127.0.0.1，不暴露公网。
 *  - assistant/message 回调携带 turn：{"sessionId","turn","text"}；turn 取
 *    event.data.turn，取不到时回调 turn:null 并记日志（本轮唯一改动）。
 *  - /inject 支持可选 image_base64/image_mime（多模态：文本+图片）。
 *  - 注册模型工具 send_proactive_message（C10 主动消息，转 POST 桥接 /proactive）。
 *  - 出站消息带类型：reply（由 /inject 触发的回合）或 proactive（其它来源触发的
 *    主动回合）。桥接按类型投递：proactive 不挂到任何用户消息下，只发该 wireborn
 *    最近一次交互的对象；不再依赖「无等待者就缓存 60s」兜底。
 *  - /session/ensure：调用方给 sessionId，按 live → resumed → created 的顺序
 *    让它可用；resume 会用与 create 完全一致的 setup（preset + 默认模型），
 *    cwd 由持久化的 session header 自动恢复，setup 不额外补。
 *
 * 单实例假设（重要）：本方案假设同一时间只有一个 DSH 进程在写 sessions 目录。
 * 多个 DSH 进程共享同一 JSONL 会话目录会互相破坏日志，需要
 * dsh-single-instance-guard 之类的保护；当前部署未安装该 guard（单实例，风险可控）。
 *
 * 依赖解析：插件目录不在 profile 的 node_modules 里，裸导入 @deepseek-ai/dsh-llm
 * 可能解析不到，因此带一层「从 dsh 安装目录 createRequire」的兜底。
 *
 * 部署：profile 条目当前指向 index.ensure.js（本文件）。Cordis 的条目热重挂载
 * 只重建实例、不重新 import 模块（Node ESM 按 URL 缓存），所以每次改代码都要用
 * 新文件名挂载；index.live.js 是上一版，保留作回滚。
 * @module dsh-jingyu-bridge
 */

import { createServer } from 'node:http';
import { randomUUID } from 'node:crypto';
import { mkdirSync, readFileSync, realpathSync, statSync } from 'node:fs';
import { resolve as resolvePath } from 'node:path';
import { createRequire } from 'node:module';
import { pathToFileURL } from 'node:url';

const TAG = '[dsh-jingyu-bridge]';

/**
 * Resolve one package exported by the dsh installation. The normal path is the
 * runtime's own package resolution (installation packages are supplied to the
 * ESM resolver); the fallback anchors a require at the running dsh CLI so an
 * absolute-path plugin outside the profile's node_modules still resolves it.
 */
async function importFromDsh(specifier) {
  try {
    return await import(specifier);
  } catch (firstError) {
    const anchor = realpathSync(process.argv[1] ?? process.execPath);
    const require = createRequire(anchor);
    const resolved = require.resolve(specifier);
    try {
      return await import(pathToFileURL(resolved).href);
    } catch (secondError) {
      throw new Error(
        '无法解析 ' + specifier + '：ESM 裸导入失败（' + String(firstError?.message ?? firstError) +
          '），安装目录解析也失败（' + String(secondError?.message ?? secondError) + '）',
      );
    }
  }
}

const llmModule = await importFromDsh('@deepseek-ai/dsh-llm').catch((error) => {
  console.error(TAG + ' 加载失败：' + String(error?.message ?? error));
  throw error;
});
const createUserMessage = llmModule.createUserMessage;
if (typeof createUserMessage !== 'function') {
  throw new Error(TAG + ' @deepseek-ai/dsh-llm 没有导出 createUserMessage');
}

// installModelSelection 会把默认 provider/model 注入 system-prompt 变量
// （{{provider}} / {{model}}）和每次 agent/request；缺了它，preset 里的
// "{{model}} has no value" 会让整个回合直接报错。
const toolsModule = await importFromDsh('@deepseek-ai/dsh-tools').catch((error) => {
  console.warn(TAG + ' @deepseek-ai/dsh-tools 不可用，跳过主动消息工具：' + String(error?.message ?? error));
  return undefined;
});
const defineTool = toolsModule?.defineTool;

const { installModelSelection } = await importFromDsh('@deepseek-ai/dsh-agent').catch((error) => {
  console.error(TAG + ' 加载失败：' + String(error?.message ?? error));
  throw error;
});

export const name = 'dsh-jingyu-bridge';
export const inject = ['agents'];

const DEFAULTS = {
  host: '127.0.0.1',
  port: 8091,
  callbackUrl: 'http://127.0.0.1:8092/callback',
  /** 新会话的工作目录（每个会话都在这里，作为 cwd 记录进 session header）。 */
  workspace: '/root/fish-workspace',
  /** agent preset id；留空 = agentPresets 的默认预设。 */
  preset: '',
  /** 回调超时（毫秒）。 */
  callbackTimeoutMs: 5000,
};

const log = (...args) => console.log(TAG, ...args);
const warn = (...args) => console.error(TAG, ...args);

/** 只取 assistant message 的文本块；工具调用/推理/附件一律忽略。 */
export function extractText(message) {
  const blocks = message?.content;
  if (!Array.isArray(blocks)) return '';
  const parts = [];
  for (const block of blocks) {
    if (block !== null && typeof block === 'object' && block.type === 'text' && typeof block.text === 'string') {
      parts.push(block.text);
    }
  }
  return parts.join('');
}

/** 出站媒体：扩展名 → MIME。 */
const MEDIA_BY_EXT = new Map([
  ['png', 'image/png'], ['jpg', 'image/jpeg'], ['jpeg', 'image/jpeg'],
  ['webp', 'image/webp'], ['gif', 'image/gif'], ['bmp', 'image/bmp'],
  ['mp3', 'audio/mpeg'], ['wav', 'audio/wav'], ['m4a', 'audio/mp4'],
  ['ogg', 'audio/ogg'], ['opus', 'audio/opus'],
]);
/** 媒体大小上限（base64 会再膨胀约 1/3）：图片 16MB、语音 32MB。 */
const MAX_IMAGE_BYTES = 16 * 1024 * 1024;
const MAX_AUDIO_BYTES = 32 * 1024 * 1024;
const MAX_MEDIA_ITEMS = 3;

function mediaMimeOf(name) {
  const m = /\.([A-Za-z0-9]+)$/.exec(String(name || ''));
  return m ? MEDIA_BY_EXT.get(m[1].toLowerCase()) : undefined;
}

/** 读取本地媒体文件，生成 {type,mime,name,data_b64}；不可用返回 undefined。 */
function readMediaFile(path) {
  try {
    const st = statSync(path);
    if (!st.isFile() || st.size <= 0) return undefined;
    const mime = mediaMimeOf(path);
    if (mime === undefined) return undefined;
    const limit = mime.startsWith('audio/') ? MAX_AUDIO_BYTES : MAX_IMAGE_BYTES;
    if (st.size > limit) return undefined;
    const data = readFileSync(path);
    return {
      type: mime.startsWith('audio/') ? 'audio' : 'image',
      mime,
      name: String(path).split('/').pop() || 'media',
      data_b64: data.toString('base64'),
    };
  } catch {
    return undefined;
  }
}

const MEDIA_PATH_RE = /(\/[^\s"'<>()（）]+?\.(?:png|jpe?g|webp|gif|bmp|mp3|wav|m4a|ogg|opus))/gi;

/** 从回复文本里找绝对媒体路径（DSH 工具产出的文件通常以路径出现）。 */
function collectMediaFromText(text) {
  const out = [];
  const seen = new Set();
  for (const match of String(text || '').matchAll(MEDIA_PATH_RE)) {
    const path = match[1];
    if (seen.has(path)) continue;
    seen.add(path);
    const item = readMediaFile(path);
    if (item !== undefined) {
      out.push(item);
      if (out.length >= MAX_MEDIA_ITEMS) break;
    }
  }
  return out;
}

/** 从 assistant message 的 image/file 数据块里取媒体（当前生产适配器多为纯文本，属前向兼容）。 */
async function collectMediaBlocks(store, message) {
  const out = [];
  const blocks = message?.content;
  if (store === undefined || !Array.isArray(blocks)) return out;
  for (const block of blocks) {
    if (block === null || typeof block !== 'object' || block.offloaded === true) continue;
    if (block.type === 'image' && block.attachment !== undefined) {
      try {
        const stored = await store.readImage(block.attachment);
        if (stored?.data !== undefined && stored.data.byteLength > 0
            && stored.data.byteLength <= MAX_IMAGE_BYTES) {
          out.push({
            type: 'image',
            mime: block.attachment.mediaType || 'image/png',
            name: block.attachment.name || 'image.png',
            data_b64: Buffer.from(stored.data).toString('base64'),
          });
        }
      } catch (error) {
        warn('读取图片附件失败：' + String(error?.message ?? error));
      }
    } else if (block.type === 'file' && block.attachment !== undefined) {
      const mime = mediaMimeOf(block.attachment.name);
      if (mime === undefined) continue;
      try {
        const chunks = [];
        let total = 0;
        for await (const chunk of store.readFileStream(block.attachment)) {
          total += chunk.byteLength;
          if (total > MAX_AUDIO_BYTES) throw new Error('文件过大');
          chunks.push(Buffer.from(chunk));
        }
        if (total > 0) {
          out.push({
            type: mime.startsWith('audio/') ? 'audio' : 'image',
            mime,
            name: block.attachment.name || 'media',
            data_b64: Buffer.concat(chunks).toString('base64'),
          });
        }
      } catch (error) {
        warn('读取文件附件失败：' + String(error?.message ?? error));
      }
    }
    if (out.length >= MAX_MEDIA_ITEMS) break;
  }
  return out;
}

/** 读 JSON 请求体（上限 1MiB，防止大包打爆内存）。 */
function readJson(req, limit = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(Object.assign(new Error('请求体过大'), { statusCode: 413 }));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (size === 0) return reject(Object.assign(new Error('请求体为空'), { statusCode: 400 }));
      try {
        resolve(JSON.parse(Buffer.concat(chunks).toString('utf8')));
      } catch {
        reject(Object.assign(new Error('请求体不是合法 JSON'), { statusCode: 400 }));
      }
    });
    req.on('error', reject);
  });
}

/**
 * @param {import('@deepseek-ai/cordis').Context} ctx profile 根上下文
 * @param {Record<string, unknown>} [config] cordis.patch.yml 里该条目的 config
 */
export function apply(ctx, config) {
  const cfg = { ...DEFAULTS, ...(config ?? {}) };
  const host = String(cfg.host || DEFAULTS.host);
  const port = Number(cfg.port) || DEFAULTS.port;
  const callbackUrl = String(cfg.callbackUrl || DEFAULTS.callbackUrl);
  const workspace = String(cfg.workspace || DEFAULTS.workspace);
  const presetId = cfg.preset === undefined || cfg.preset === null || cfg.preset === '' ? undefined : String(cfg.preset);
  const callbackTimeoutMs = Number(cfg.callbackTimeoutMs) || DEFAULTS.callbackTimeoutMs;

  /** sessionId → AgentHandle（同时把 agent 的 owner fiber 挂在本插件下）。 */
  const sessions = new Map();
  const attachments = ctx.get('attachments');
  const tools = ctx.get('tools');
  const proactiveUrl = new URL('/proactive', callbackUrl).href;
  /** 回调串行链：保证同一会话的多条 assistant/message 按序到达桥接服务。 */
  let callbackChain = Promise.resolve();
  let closed = false;

  try {
    mkdirSync(workspace, { recursive: true });
  } catch (error) {
    warn('工作目录创建失败（继续，cwd 可能被 header 记为不存在路径）：' + workspace + ' → ' + String(error?.message ?? error));
  }

  /** 让新会话加入默认（或指定）agent preset：工具、提示词、人格都来自这里。 */
  async function joinPreset(agentCtx) {
    const presets = ctx.get('agentPresets');
    if (!presets) {
      warn('agentPresets 服务不可用，跳过 preset 挂载（回退到全局层）');
      return;
    }
    try {
      const preset = await presets.mount(agentCtx, presetId);
      log('会话加入预设：' + preset.id);
    } catch (error) {
      warn('agent preset 挂载失败（回退到全局层）：' + String(error?.message ?? error));
    }
  }

  /**
   * 读部署的默认模型选择。preset 的提示词里用了 {{provider}} / {{model}}，
   * 不注入就会在第一次 assemble 时报 "prompt variable ... has no value"。
   */
  function readDefaultSelection() {
    const service = ctx.get('agentDefaultModel');
    if (!service) {
      warn('agentDefaultModel 服务不可用：新会话不会带默认模型（preset 若引用 {{model}} 会失败）');
      return undefined;
    }
    try {
      return service.currentSelection();
    } catch (error) {
      warn('读取默认模型失败：' + String(error?.message ?? error));
      return undefined;
    }
  }

  /**
   * 默认模型 + preset 装配。create 与 resume 必须用完全一致的 setup：
   * 少了 joinPreset 会丢工具/提示词，少了 installModelSelection 会撞 {{model}}。
   */
  function buildAgentWiring() {
    const selection = readDefaultSelection();
    const agentOptions = selection === undefined
      ? {}
      : { provider: selection.provider, model: selection.model };
    // dsh-agent 的 installModelSelection 约定的可变引用：assemble 后记录实际
    // 生效的 selection，agent/request 再读它。
    const selectionRef = selection === undefined ? undefined : { current: selection, assembled: undefined };
    const setup = async (agentCtx) => {
      await joinPreset(agentCtx);
      if (selectionRef !== undefined) installModelSelection(agentCtx, selectionRef);
    };
    return { agentOptions, setup };
  }

  /**
   * 官方以编程方式创建会话：ctx.agents.create()（由 dsh-agent-loop 通过
   * AgentFactory 实现，内部走 sessions.prepare + 持久化 + publish）。
   */
  async function createSession() {
    const sessionId = randomUUID();
    const { agentOptions, setup } = buildAgentWiring();

    let handle;
    try {
      handle = await ctx.agents.create({
        sessionId,
        meta: { cwd: workspace },
        agentOptions,
        setup,
      });
    } catch (error) {
      throw new Error('ctx.agents.create 失败：' + String(error?.message ?? error));
    }
    // 创建后等待 agent 进入空闲，避免首个 followup 撞上初始化中的回合。
    await handle.agent.whenIdle();
    sessions.set(sessionId, handle);
    log('已创建会话 sessionId=' + sessionId + '（当前存活 ' + sessions.size + ' 个）');
    return handle.agent.session?.id ?? sessionId;
  }

  /** 持久化错误的类型名（这些错误类都用 error.name 区分）。 */
  function errorKind(error) {
    const kind = error?.name;
    return typeof kind === 'string' && kind !== '' && kind !== 'Error' ? kind : 'unknown';
  }

  /**
   * 让调用方给定的 sessionId 变成可用 agent：live → resumed → created。
   * 只有 SessionPersistenceNotFoundError（没有落盘日志）才允许 create；
   * 日志损坏/被占用/其他错误一律返回错误，不自动清理、不改数据库。
   *
   * 注意：resume 的 cwd 由持久化的 session header 恢复（AgentLoop.resumeWith
   * 把 handle.header 作为 meta 交给 sessions.prepare），所以这里不需要补 meta。
   */
  async function ensureSession(sessionId) {
    if (ctx.agents.get(sessionId) !== undefined) {
      log('ensure: get session=' + sessionId + ' -> live');
      return { ok: true, sessionId, source: 'live' };
    }

    const { agentOptions, setup } = buildAgentWiring();

    log('ensure: resume session=' + sessionId);
    let handle;
    try {
      handle = await ctx.agents.resume({
        resumeSessionId: sessionId,
        agentOptions,
        setup,
      });
    } catch (error) {
      const kind = errorKind(error);
      const detail = String(error?.message ?? error);
      if (kind === 'SessionPersistenceNotFoundError') {
        log('ensure: create session=' + sessionId + '（resume 未找到落盘日志）');
        try {
          handle = await ctx.agents.create({
            sessionId,
            meta: { cwd: workspace },
            agentOptions,
            setup,
          });
        } catch (createError) {
          const createDetail = String(createError?.message ?? createError);
          log('ensure: error create_failed session=' + sessionId);
          return { ok: false, sessionId, error: 'create_failed', detail: createDetail };
        }
        await handle.agent.whenIdle();
        sessions.set(sessionId, handle);
        log('ensure: created session=' + sessionId);
        return { ok: true, sessionId, source: 'created' };
      }
      if (kind === 'SessionPersistenceCorruptionError' || kind === 'SessionFormatUnsupportedError') {
        log('ensure: error corrupt session=' + sessionId + '（' + kind + '）');
        return { ok: false, sessionId, error: 'corrupt', detail };
      }
      if (kind === 'SessionAlreadyOwnedError') {
        log('ensure: error owned session=' + sessionId);
        return { ok: false, sessionId, error: 'owned', detail };
      }
      log('ensure: error ' + kind + ' session=' + sessionId);
      return { ok: false, sessionId, error: kind, detail };
    }

    await handle.agent.whenIdle();
    sessions.set(sessionId, handle);
    log('ensure: resumed session=' + sessionId);
    return { ok: true, sessionId, source: 'resumed' };
  }

  /** 投递一条用户消息（文本+可选图片）到指定会话；返回 false 表示 session 不在存活表里。 */
  async function inject(sessionId, text, imageBase64, imageMime) {
    // ctx.agents.get(id) 的入参就是 SessionId（Agent.id 与 Session.id 共用同一个 id）。
    const agent = ctx.agents.get(sessionId);
    if (agent === undefined) return false;
    const content = [{ type: 'text', text }];
    if (typeof imageBase64 === 'string' && imageBase64.trim() !== '') {
      if (attachments === undefined) {
        throw Object.assign(new Error('attachments 服务不可用，无法接收图片'), { statusCode: 500 });
      }
      const bytes = Buffer.from(imageBase64, 'base64');
      if (bytes.length === 0) {
        throw Object.assign(new Error('image_base64 解码为空'), { statusCode: 400 });
      }
      const ref = await attachments.saveImage({
        data: new Uint8Array(bytes),
        mediaType: typeof imageMime === 'string' && imageMime !== '' ? imageMime : 'image/jpeg',
        name: 'tinode-image',
      });
      content.push({ type: 'image', attachment: ref });
    }
    agent.followup(
      createUserMessage({
        content,
        source: { kind: 'plugin:dsh-jingyu-bridge' },
      }),
    );
    // 标记：这个会话的下一个回合是对 Tinode 用户消息的回复（reply）。
    pendingReplies.add(sessionId);
    return true;
  }

  /** 把 assistant 文本回传桥接服务；串行 + 单次尝试 + 超时，失败只记日志。 */
  function sendCallback(payload) {
    if (closed) return callbackChain;
    callbackChain = callbackChain
      .then(async () => {
        const response = await fetch(callbackUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json; charset=utf-8' },
          body: JSON.stringify(payload),
          signal: AbortSignal.timeout(callbackTimeoutMs),
        });
        const body = await response.text().catch(() => '');
        if (!response.ok) {
          warn('回调被拒绝 HTTP ' + response.status + '（session=' + payload.sessionId + '）: ' + body.slice(0, 200));
        }
      })
      .catch((error) => {
        warn('回调失败（session=' + payload.sessionId + '）：' + String(error?.message ?? error));
      });
    return callbackChain;
  }

  /** 每会话缓冲本轮最后一条 assistant 文本/媒体，turn/end 时统一发一条。 */
  const finalReplies = new Map();
  /**
   * 回合类型：/inject 触发的回合 = reply，其它来源（定时提醒、主动任务）= proactive。
   * 在 turn/start 时定类型，turn/end 随回调发给桥接。
   */
  const pendingReplies = new Set();
  const turnTypes = new Map();

  /**
   * 全局 session/event 监听。本插件挂在 profile 根上下文，非 agent 作用域，
   * 因此所有会话（含普通 Web 会话）的 assistant/message 都会到这里。
   *
   * A 类消息丢失修复（2026-11-02）：不再把每条 assistant/message 独立当回复发出，
   * 只缓冲本轮最后一条，收到 turn/end 才发最终回复；中途文本不会进聊天。
   */
  async function onSessionEvent(session, event) {
    if (event?.type === 'turn/start') {
      const sid = String(session.id);
      // /inject 刚投递过的会话，这一回合是对用户消息的回复；否则是主动回合。
      const type = pendingReplies.delete(sid) ? 'reply' : 'proactive';
      turnTypes.set(sid, type);
      // 上一轮若没收到 turn/end（连续系统任务时会出现），先把上一轮最后一条补发，避免被本轮覆盖。
      const previous = finalReplies.get(sid);
      if (previous !== undefined) {
        finalReplies.delete(sid);
        const payload = { sessionId: sid, text: previous.text, type: previous.type ?? 'proactive' };
        payload.turn = typeof previous.turn === 'number' ? previous.turn : null;
        if (previous.media.length > 0) payload.media = previous.media;
        void sendCallback(payload);
      }
      return;
    }
    if (event?.type === 'turn/end') {
      const sid = String(session.id);
      const pending = finalReplies.get(sid);
      finalReplies.delete(sid);
      const type = turnTypes.get(sid) ?? pending?.type ?? 'proactive';
      turnTypes.delete(sid);
      if (pending === undefined) return;
      const payload = { sessionId: sid, text: pending.text, type };
      if (typeof pending.turn === 'number') {
        payload.turn = pending.turn;
      } else {
        warn('assistant/message 缺少数字 turn 字段（session=' + sid + '），回调 turn=null');
        payload.turn = null;
      }
      if (pending.media.length > 0) payload.media = pending.media;
      void sendCallback(payload);
      return;
    }
    if (event?.type !== 'assistant/message') return;
    const message = event.data?.message;
    const text = extractText(message);
    const media = [];
    try {
      media.push(...(await collectMediaBlocks(attachments, message)));
    } catch (error) {
      warn('收集附件媒体失败：' + String(error?.message ?? error));
    }
    for (const item of collectMediaFromText(text)) {
      if (media.length >= MAX_MEDIA_ITEMS) break;
      media.push(item);
    }
    if (text.trim() === '' && media.length === 0) return;
    finalReplies.set(String(session.id), {
      text,
      media,
      turn: event.data?.turn,
      type: turnTypes.get(String(session.id)) ?? 'proactive',
    });
  }

  if (tools !== undefined && typeof defineTool === 'function') {
    const disposeTool = tools.register(defineTool({
      name: 'send_proactive_message',
      description:
        '主动向 Tinode 发一条消息（数字生命主动开口）。只会发给该数字生命最近一次收到消息的对象（24 小时内有效），不跨用户、不群发；target 可省略。每小时最多 10 条。可以只发文本，或附带一张图片/一段语音（media_path 传服务器本地绝对路径，png/jpg/webp/mp3/wav 等）。',
      parameters: {
        target: { type: 'string', description: '可选。省略则自动发往最近一次交互的对象；填了必须与之一致，否则拒绝' },
        text: { type: 'string', description: '要发送的文本（可为空，但 text 与 media_path 至少有一个）' },
        media_path: { type: 'string', description: '要附带的图片/语音文件绝对路径（可选，图片≤16MB、语音≤60秒）' },
      },
      output: {
        schema: { type: 'json' },
        render: (_args, value) => [{ type: 'text', text: value?.ok ? '已发送主动消息' : '发送失败' }],
      },
      isConcurrencySafe: () => true,
      execute: async (args, exec) => {
        const target = String(args?.target ?? '').trim();
        const text = String(args?.text ?? '');
        if (target !== '' && !/^(usr|grp)[A-Za-z0-9_-]+$/.test(target)) {
          throw new Error('target 必须是 usr...（私聊）或 grp...（群聊），或留空');
        }
        const mediaPath = String(args?.media_path ?? '').trim();
        const media = [];
        if (mediaPath !== '') {
          const item = readMediaFile(resolvePath(mediaPath));
          if (item === undefined) throw new Error('media_path 不是可用的图片/音频文件（图片≤16MB，语音≤32MB）');
          media.push(item);
        }
        if (text.trim() === '' && media.length === 0) throw new Error('text 和 media_path 至少有一个不能为空');
        const sessionId = String(exec?.agent?.session?.id ?? '');
        const match = /^tinode:([^:]+):/.exec(sessionId);
        if (match === null) {
          throw new Error('当前会话不是 Tinode 数字生命会话（sessionId=' + sessionId + '），无法主动发消息');
        }
        const agentUid = decodeURIComponent(match[1]);
        const response = await fetch(proactiveUrl, {
          method: 'POST',
          headers: { 'content-type': 'application/json; charset=utf-8' },
          body: JSON.stringify({ agent_uid: agentUid, target, text, ...(media.length > 0 ? { media } : {}) }),
          signal: AbortSignal.timeout(10000),
        });
        const data = await response.json().catch(() => ({}));
        if (!response.ok || data.ok !== true) {
          throw new Error('主动消息发送失败（HTTP ' + response.status + '）：' + (data.error ?? 'unknown'));
        }
        return { ok: true, target, agent_uid: agentUid, media_count: media.length };
      },
    }));
    ctx.effect(() => () => disposeTool(), 'dsh-jingyu-bridge.proactive-tool');
    log('已注册工具 send_proactive_message → ' + proactiveUrl);
  } else {
    warn('tools 服务或 defineTool 不可用，未注册 send_proactive_message');
  }

  const server = createServer(async (req, res) => {
    const reply = (status, body) => {
      const text = JSON.stringify(body);
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'content-length': Buffer.byteLength(text),
      });
      res.end(text);
    };

    let pathname = '/';
    try {
      pathname = new URL(req.url ?? '/', 'http://127.0.0.1').pathname;
    } catch {
      return reply(400, { error: '非法 URL' });
    }

    try {
      if (req.method === 'GET' && pathname === '/health') {
        return reply(200, { ok: true, sessions: sessions.size });
      }

      if (pathname === '/session/new') {
        if (req.method !== 'POST') return reply(405, { error: 'method not allowed' });
        const sessionId = await createSession();
        return reply(200, { sessionId });
      }

      if (pathname === '/session/ensure') {
        if (req.method !== 'POST') return reply(405, { error: 'method not allowed' });
        const body = await readJson(req);
        const sessionId = typeof body.sessionId === 'string' ? body.sessionId.trim() : '';
        if (sessionId === '') return reply(400, { error: 'sessionId 必填且必须是字符串' });
        const result = await ensureSession(sessionId);
        if (result.ok) return reply(200, result);
        const status = result.error === 'owned' ? 409 : result.error === 'corrupt' ? 422 : 500;
        return reply(status, result);
      }

      if (pathname === '/inject') {
        if (req.method !== 'POST') return reply(405, { error: 'method not allowed' });
        const body = await readJson(req);
        const sessionId = typeof body.sessionId === 'string' ? body.sessionId.trim() : '';
        const text = typeof body.text === 'string' ? body.text : '';
        const imageBase64 = typeof body.image_base64 === 'string' ? body.image_base64 : '';
        const imageMime = typeof body.image_mime === 'string' ? body.image_mime : '';
        if (sessionId === '') return reply(400, { error: 'sessionId 必填且必须是字符串' });
        if (text.trim() === '' && imageBase64.trim() === '') {
          return reply(400, { error: 'text 和 image_base64 至少有一个不能为空' });
        }
        if (!(await inject(sessionId, text, imageBase64, imageMime))) {
          return reply(404, { error: 'session 不存在（没有存活的 agent）', sessionId });
        }
        log('已注入 session=' + sessionId + ' len=' + text.length + (imageBase64 ? ' +image' : ''));
        return reply(200, { ok: true, sessionId });
      }

      return reply(404, { error: 'not found' });
    } catch (error) {
      const status = Number(error?.statusCode) || 500;
      warn('处理 ' + pathname + ' 出错（HTTP ' + status + '）：' + String(error?.message ?? error));
      return reply(status, { error: String(error?.message ?? error) });
    }
  });

  ctx.effect(() => {
    const offSessionEvent = ctx.on('session/event', (session, event) => {
      void onSessionEvent(session, event);
    });

    server.on('clientError', (error, socket) => {
      warn('HTTP 客户端错误：' + String(error?.message ?? error));
      socket.destroy();
    });
    server.on('error', (error) => {
      warn('HTTP 服务错误（端口 ' + host + ':' + port + '）：' + String(error?.message ?? error));
    });
    server.listen(port, host, () => {
      log('已挂载：监听 http://' + host + ':' + port + '（回调 ' + callbackUrl + '）');
    });

    return async () => {
      closed = true;
      offSessionEvent();
      await new Promise((resolve) => server.close(() => resolve()));
      for (const [sessionId, handle] of sessions) {
        try {
          await handle.dispose();
        } catch (error) {
          warn('释放会话失败 session=' + sessionId + '：' + String(error?.message ?? error));
        }
      }
      sessions.clear();
      log('已卸载');
    };
  }, 'dsh-jingyu-bridge.lifecycle');

  log('插件已加载（profile 级），等待 HTTP 端口就绪……');
}
