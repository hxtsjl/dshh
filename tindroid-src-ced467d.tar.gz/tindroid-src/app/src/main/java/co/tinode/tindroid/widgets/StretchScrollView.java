package co.tinode.tindroid.widgets;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.OvershootInterpolator;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.widget.NestedScrollView;

/**
 * 鲸yu: 和 {@link StretchRecyclerView} 手感一致的滚动容器。
 * <p>
 * NestedScrollView 没有 EdgeEffectFactory 这类官方钩子，所以这里用同一套参数
 * （0.35 阻尼、96dp 上限、Overshoot 回弹）自己做整页位移；关键在于
 * {@code setOverScrollMode(OVER_SCROLL_NEVER)}，把系统自己的 overscroll 关掉，
 * 不存在两套效果互相抢事件，也就不会抽搐。
 */
public class StretchScrollView extends NestedScrollView {

    private static final float DAMPING = 0.35f;
    private static final float MAX_STRETCH_DP = 96f;
    private static final long RELEASE_DURATION = 260L;

    private final float mMaxStretch;
    private float mStartY;
    private float mOffset;

    public StretchScrollView(@NonNull Context context) {
        this(context, null);
    }

    public StretchScrollView(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        mMaxStretch = MAX_STRETCH_DP * getResources().getDisplayMetrics().density;
        // 关掉系统 overscroll，只留我们自己的位移回弹。
        setOverScrollMode(OVER_SCROLL_NEVER);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        handleStretch(ev);
        return super.dispatchTouchEvent(ev);
    }

    private void handleStretch(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                mStartY = event.getY();
                mOffset = 0f;
                break;
            case MotionEvent.ACTION_MOVE: {
                float dy = (event.getY() - mStartY) * DAMPING;
                if (dy > 0 && !canScrollVertically(-1)) {
                    mOffset = Math.min(dy, mMaxStretch);
                } else if (dy < 0 && !canScrollVertically(1)) {
                    mOffset = Math.max(dy, -mMaxStretch);
                } else if (mOffset != 0f) {
                    mOffset = 0f;
                    animate().translationY(0f).setDuration(120L).start();
                }
                if (mOffset != 0f) {
                    animate().cancel();
                    setTranslationY(mOffset);
                }
                break;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (mOffset != 0f) {
                    mOffset = 0f;
                    animate()
                            .translationY(0f)
                            .setDuration(RELEASE_DURATION)
                            .setInterpolator(new OvershootInterpolator(0.9f))
                            .start();
                }
                break;
            default:
                break;
        }
    }
}
