package co.tinode.tindroid;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Locale;

import co.tinode.tindroid.db.BaseDb;
import co.tinode.tindroid.widgets.SquareProgressView;

/**
 * 鲸yu 启动页：白底 + 几何鲸鱼 Logo + 方块进度条；到 100% 不自动跳转，
 * 等用户点击屏幕后再进入登录页/会话页。
 */
public class InitRouterActivity extends BaseActivity {
    private static final long SPLASH_DURATION_MS = 2200L;

    private SquareProgressView mProgress;
    private ImageView mLogo;
    private TextView mTagline;
    private TextView mPercent;
    private TextView mStatus;
    private boolean mTaglineShown;
    private ValueAnimator mAnimator;
    private boolean mReady;
    private boolean mNavigated;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UiUtils.setupSystemToolbar(this);

        setContentView(R.layout.activity_splash);
        applyEdgeToEdgeInsets(findViewById(android.R.id.content));

        mProgress = findViewById(R.id.splashProgress);
        mLogo = findViewById(R.id.splashLogo);
        if (mLogo != null && mLogo.getDrawable() instanceof Animatable) {
            ((Animatable) mLogo.getDrawable()).start();
        }
        mTagline = findViewById(R.id.splashTagline);
        mPercent = findViewById(R.id.splashPercent);
        mStatus = findViewById(R.id.splashStatus);

        findViewById(R.id.splashRoot).setOnClickListener(view -> {
            if (mReady) {
                route();
            }
        });

        mAnimator = ValueAnimator.ofFloat(0f, 1f);
        mAnimator.setDuration(SPLASH_DURATION_MS);
        mAnimator.addUpdateListener(animation -> render((float) animation.getAnimatedValue()));
        mAnimator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                render(1f);
            }
        });
        mAnimator.start();
    }

    private void render(float value) {
        if (mProgress == null) {
            return;
        }
        mProgress.setProgress(value);
        // Logo 是 AnimatedVectorDrawable（trimPath）自行播完，这里只处理文案与进度数字。
        if (!mTaglineShown && value >= 0.72f && mTagline != null) {
            mTaglineShown = true;
            mTagline.animate().alpha(1f).setDuration(500L).start();
        }
        mPercent.setText(String.format(Locale.getDefault(), "%d%%", Math.round(value * 100)));
        if (value >= 1f && !mReady) {
            // 100% 后等 0.5 秒再提示「点击任意处开始」。
            final TextView status = mStatus;
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                mReady = true;
                if (status != null) {
                    status.setText(R.string.splash_ready);
                }
            }, 500L);
        }
    }

    private void route() {
        if (mNavigated) {
            return;
        }
        mNavigated = true;
        Intent launch = new Intent(this, BaseDb.getInstance().isReady() ?
                ChatsActivity.class : LoginActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(launch);
        // 启动页进主界面：300ms 缩放 + 淡入。
        overridePendingTransition(R.anim.splash_enter, android.R.anim.fade_out);
        finish();
    }

    @Override
    protected void onDestroy() {
        if (mAnimator != null) {
            mAnimator.cancel();
            mAnimator = null;
        }
        super.onDestroy();
    }
}
