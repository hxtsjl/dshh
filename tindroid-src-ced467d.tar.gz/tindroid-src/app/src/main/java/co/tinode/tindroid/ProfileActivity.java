package co.tinode.tindroid;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import com.canhub.cropper.CropImageContract;
import com.canhub.cropper.CropImageContractOptions;
import com.canhub.cropper.CropImageView;
import coil.Coil;
import coil.request.ImageRequest;
import coil.size.Scale;
import org.json.JSONObject;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import androidx.core.widget.NestedScrollView;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;

import co.tinode.tindroid.media.VxCard;
import co.tinode.tinodesdk.MeTopic;
import co.tinode.tinodesdk.PromisedReply;
import co.tinode.tinodesdk.Tinode;
import co.tinode.tinodesdk.Topic;
import co.tinode.tinodesdk.model.ServerMessage;
import co.tinode.tinodesdk.model.TheCard;

/**
 * 鲸yu 个人主页 v2。
 * <p>
 * · 顶部背景图固定在最底层（屏幕高度的 2/5），不随滑动折叠；
 * 卡片流叠在图片之上，向上滚动时浮到图片上层；
 * · 查看自己：可编辑昵称/签名、可点背景图换封面；
 * · 查看他人（访客模式）：隐藏设置/关于/致谢三张卡片与编辑按钮，背景图不可改；
 * 如果对方是 wireborn，再隐藏「我的 wireborn」卡片。
 * <p>
 * 注意：除个人主页自身信息外，卡片数据目前仍是本地 Mock。
 */
public class ProfileActivity extends BaseActivity {

    /**
     * 目标用户 ID。为空或等于自己时表示查看自己的主页。
     */
    public static final String EXTRA_USER_ID = "extra_user_id";
    public static final String EXTRA_USER_NAME = "extra_user_name";
    public static final String EXTRA_USER_PHOTO = "extra_user_photo";
    /**
     * 目标用户是否为 wireborn。客户端暂时拿不到可靠标记，由调用方传入；
     * 未传时用 {@link #isWirebornId(String)} 做保守判断。
     */
    public static final String EXTRA_IS_WIREBORN = "extra_is_wireborn";
    /**
     * 管理某个 wireborn：传它的 uid，进入「主页即管理页」编辑态。
     * 保存走 8090 /auth/proxy → 独立 Tinode 实例，以 wireborn 身份提交。
     */
    public static final String EXTRA_MANAGE_UID = "extra_manage_uid";

    // 卡片 2 最多显示的 wireborn 槽位；达到上限后不再显示末尾的「+」。
    private static final int MAX_WIREBORN_SLOTS = 3;
    // Mock：当前用户拥有的 wireborn 数量（接真实接口后替换）。
    private static final int MOCK_WIREBORN_COUNT = 3;
    // 第一张卡片与背景图的重叠高度，制造「卡片浮在图上」的层次感。
    private static final int CARD_OVERLAP_DP = 64;

    private static final int[] WIREBORN_AVATARS = {
            R.id.wirebornAvatar1, R.id.wirebornAvatar2, R.id.wirebornAvatar3
    };

    private static final String BG_PREFS = "jingyu_profile_bg";
    // B5: 背景 ref 的跨端同步接口（tinode-admin）。
    private static final String PROFILE_BG_API = "http://8.138.57.26:8090/profile/bg";

    private boolean mIsSelf = true;
    private boolean mIsWireborn = false;
    /** 管理态：查看某个 wireborn 并允许编辑（不是自己，也不是普通访客）。 */
    private boolean mCanEdit = false;
    private String mManageUid;
    private String mUserId;
    private ProxySession mProxy;
    private VxCard mProxyPub;
    private ActivityResultLauncher<String> mPickAvatar;
    private ActivityResultLauncher<CropImageContractOptions> mCropAvatar;
    private ActivityResultLauncher<String> mPickBackground;
    private ActivityResultLauncher<CropImageContractOptions> mCropBackground;

    @Override
    protected void onResume() {
        super.onResume();
        // 背景只在 onCreate 拉一次；换包/重装后首拉若赶上 Tinode 未就绪会永久回退默认。
        // 回前台再拉一次（本地 prefs 命中就直接渲染，不会再请求 8090）。
        View header = findViewById(R.id.profileHeader);
        loadSavedBackground(header instanceof ImageView ? (ImageView) header : null);
        // 「我的数字生命」列表：每次回前台（含从管理页返回）都强制回源，
        // 否则改完头像/昵称回到这一页看到的还是上一次的缓存。
        refreshWirebornList();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UiUtils.setupSystemToolbar(this);
        setContentView(R.layout.activity_profile);
        applyFullBleedInsets();

        setupToolbar();
        mPickAvatar = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null && mCropAvatar != null) {
                mCropAvatar.launch(CropHelper.avatar(this, uri));
            }
        });
        mCropAvatar = registerForActivityResult(new CropImageContract(), (CropImageView.CropResult result) -> {
            if (result == null || !result.isSuccessful() || result.getUriContent() == null) {
                showCropError(result);
                return;
            }
            uploadAvatar(result.getUriContent());
        });
        mPickBackground = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null && mCropBackground != null) {
                mCropBackground.launch(CropHelper.background(this, uri, R.string.crop_background_title));
            }
        });
        mCropBackground = registerForActivityResult(new CropImageContract(), (CropImageView.CropResult result) -> {
            if (result == null || !result.isSuccessful() || result.getUriContent() == null) {
                showCropError(result);
                return;
            }
            uploadBackground(result.getUriContent());
        });
        readTarget();
        setupHeaderPanel();
        bindProfileCard();
        setupWirebornCard();
        setupListItems();
        applyVisitorMode();
        if (mCanEdit) {
            loadManagedProfile();
        }
    }

    @Override
    protected void onDestroy() {
        if (mProxy != null) {
            mProxy.close();
            mProxy = null;
        }
        super.onDestroy();
    }

    private void showCropError(CropImageView.CropResult result) {
        // 用户主动取消不算失败，只提示真正的裁剪错误。
        if (result != null && result.getError() != null) {
            Toast.makeText(this, R.string.image_crop_failed, Toast.LENGTH_SHORT).show();
        }
    }


    // B2: 背景要铺到状态栏下面，所以顶部 inset 只给工具栏，其余交给背景图。
    private void applyFullBleedInsets() {
        final View root = findViewById(android.R.id.content);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(bars.left, 0, bars.right, bars.bottom);
            View toolbar = findViewById(R.id.toolbar);
            if (toolbar != null) {
                toolbar.setPadding(toolbar.getPaddingLeft(), bars.top,
                        toolbar.getPaddingRight(), toolbar.getPaddingBottom());
            }
            return WindowInsetsCompat.CONSUMED;
        });
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar == null) {
            return;
        }
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar != null) {
            bar.setDisplayHomeAsUpEnabled(true);
            bar.setDisplayShowHomeEnabled(true);
            bar.setDisplayShowTitleEnabled(false);
        }
        toolbar.setTitle(null);
        toolbar.setSubtitle(null);
        toolbar.setNavigationOnClickListener(v -> finish());
    }

    private void readTarget() {
        final Intent intent = getIntent();
        final String manageUid = intent == null ? null : intent.getStringExtra(EXTRA_MANAGE_UID);
        if (!TextUtils.isEmpty(manageUid)) {
            // 管理 wireborn：不是自己，但可编辑（三态主页的第三种状态）。
            mCanEdit = true;
            mIsSelf = false;
            mIsWireborn = true;
            mManageUid = manageUid;
            mUserId = manageUid;
            return;
        }
        final String targetId = intent == null ? null : intent.getStringExtra(EXTRA_USER_ID);

        // 重要：MeTopic.getName() 返回的是 topic 名 "me"，不是 uid；自己的 uid 要用 getMyId()。
        // 之前用 getName() 导致 profile_bg 一直写成 key='me'。
        final String myId = Cache.getTinode().getMyId();

        mIsSelf = TextUtils.isEmpty(targetId) || (myId != null && myId.equals(targetId));
        mUserId = mIsSelf ? myId : targetId;
        mIsWireborn = !mIsSelf && ((intent != null && intent.getBooleanExtra(EXTRA_IS_WIREBORN, false))
                || isWirebornId(mUserId) || Wireborns.isWireborn(this, mUserId));
    }

    // 顶部背景图固定高度 = 屏幕 2/5；卡片区从图片底部上方 64dp 开始，随滚动浮到图上。
    private void setupHeaderPanel() {
        final int screenHeight = getResources().getDisplayMetrics().heightPixels;
        // B2: 背景铺满整页（含状态栏下方），卡片浮在上面。
        final int headerHeight = screenHeight;

        View header = findViewById(R.id.profileHeader);
        if (header != null) {
            ViewGroup.LayoutParams lp = header.getLayoutParams();
            if (lp != null) {
                lp.height = headerHeight;
                header.setLayoutParams(lp);
            }
            header.setClickable(false);
        }

        loadSavedBackground(header instanceof ImageView ? (ImageView) header : null);

        final NestedScrollView scroll = findViewById(R.id.profileScroll);
        if (scroll == null) {
            return;
        }
        // 第一张卡片从屏幕 40% 处开始（比顶部背景低，形成卡片压图的效果）。
        int topInset = Math.max(0, Math.round(screenHeight * 0.4f) - dp(CARD_OVERLAP_DP));
        scroll.setPadding(0, topInset, 0, 0);
        // 关键：允许子 View 画到 padding 区域，卡片才能浮在背景图之上。
        scroll.setClipToPadding(false);

        if (!mIsSelf && !mCanEdit) {
            // 访客模式不允许修改封面。
            return;
        }
        // 背景图在滚动容器下方，直接点不到：用手势识别判断点击是否落在图片区域。
        final GestureDetector detector = new GestureDetector(this,
                new GestureDetector.SimpleOnGestureListener() {
                    @Override
                    public boolean onDown(@androidx.annotation.NonNull MotionEvent e) {
                        return true;
                    }

                    @Override
                    public boolean onSingleTapUp(@androidx.annotation.NonNull MotionEvent e) {
                        float contentY = e.getY() + scroll.getScrollY();
                        if (contentY < scroll.getPaddingTop()) {
                            showCoverSheet();
                            return true;
                        }
                        return false;
                    }
                });
        // 只处理「点背景图」手势；回弹交给系统 overScroll（Android 12+ 原生拉伸），
        // 不再自研 translationY，避免和滚动抢事件导致抽搐。
        scroll.setOnTouchListener((v, event) -> {
            detector.onTouchEvent(event);
            // 返回 false，把事件继续交给 NestedScrollView 处理滚动。
            return false;
        });
    }

    private void bindProfileCard() {
        if (mCanEdit) {
            bindManagedProfileCard();
            return;
        }
        ImageView avatar = findViewById(R.id.profileAvatar);
        TextView name = findViewById(R.id.profileName);
        TextView idView = findViewById(R.id.profileId);
        TextView signature = findViewById(R.id.profileSignature);

        if (mIsSelf) {
            MeTopic<VxCard> me = Cache.getTinode().getMeTopic();
            VxCard pub = me == null ? null : me.getPub();
            final String myId = Cache.getTinode().getMyId();
            UiUtils.setAvatar(avatar, pub, myId, false);
            if (avatar != null) {
                // 只有本人能换头像：点开底部弹栏，再从设备选图进 1:1 圆形裁剪。
                avatar.setOnClickListener(v -> showAvatarSheet());
            }
            String fn = pub == null ? null : pub.fn;
            if (!TextUtils.isEmpty(fn) && name != null) {
                name.setText(fn);
            }
            if (signature != null) {
                // 签名存 Tinode public.note，服务端为准。
                signature.setText(pub == null || TextUtils.isEmpty(pub.note)
                        ? getString(R.string.profile_signature_empty) : pub.note);
            }
            if (!TextUtils.isEmpty(myId) && idView != null) {
                idView.setText("ID：" + myId);
            }
            // 头像优先用 8090 的副本（重装/换机后 Tinode 文件可能已被 GC）。
            UiUtils.applyProfilePhoto(avatar, myId);
            renderProfileMeta(pub);
        } else {
            final Intent intent = getIntent();
            String fn = intent == null ? null : intent.getStringExtra(EXTRA_USER_NAME);
            String photo = intent == null ? null : intent.getStringExtra(EXTRA_USER_PHOTO);
            if (TextUtils.isEmpty(fn)) {
                fn = getString(R.string.profile_unknown_user);
            }
            UiUtils.setAvatarFromRef(avatar, photo, fn, mUserId);
            if (name != null) {
                name.setText(fn);
            }
            if (idView != null && !TextUtils.isEmpty(mUserId)) {
                idView.setText("ID：" + mUserId);
            }
            if (signature != null) {
                signature.setText(R.string.profile_signature_visitor);
            }
            // 另一账号看已改的资料：订阅一次拿最新 desc。
            refreshVisitorProfile();
        }
    }

    private void setupWirebornCard() {
        if (!mIsSelf) {
            // 访客/管理态不显示「我的数字生命」卡片，也不必拉列表。
            return;
        }
        // 旧的 Mock 头像槽位停用，改成真实列表（每行一个 wireborn + 管理入口）。
        View slots = findViewById(R.id.wirebornAvatars);
        if (slots != null) {
            slots.setVisibility(View.GONE);
        }
        final LinearLayout list = findViewById(R.id.wirebornList);
        // 首帧先渲染本地缓存，真正回源放在 onResume/refreshWirebornList 里，
        // 这样从管理页返回时列表也能刷新，而不是只在 onCreate 拉一次。
        renderWirebornList(list, Wireborns.cachedOwned(this));

        // 账号级操作：创建 wireborn / 重置密码，跳 8090 现有流程（不做免密）。
        View manage = findViewById(R.id.manageDigitalLives);
        if (manage != null) {
            manage.setOnClickListener(v -> startActivity(new Intent(this, AgentWebViewActivity.class)));
        }
        View create = findViewById(R.id.btnCreateWireborn);
        if (create != null) {
            create.setOnClickListener(v -> startActivity(new Intent(this, AgentWebViewActivity.class)));
        }
        View reset = findViewById(R.id.btnResetAgentPassword);
        if (reset != null) {
            reset.setOnClickListener(v -> startActivity(new Intent(this, AgentWebViewActivity.class)));
        }
    }

    /**
     * 回源「我的数字生命」列表：先渲染本地缓存，网络回来后重绘。
     * 每次 onResume 都调用，覆盖「在管理页改完头像/昵称返回」的场景。
     */
    private void refreshWirebornList() {
        if (!mIsSelf) {
            return;
        }
        final LinearLayout list = findViewById(R.id.wirebornList);
        if (list == null) {
            return;
        }
        renderWirebornList(list, Wireborns.cachedOwned(this));
        final Tinode tinode = Cache.getTinode();
        final String token = tinode == null ? null : tinode.getAuthToken();
        Wireborns.fetchOwned(this, token, () -> {
            if (isFinishing() || isDestroyed()) {
                return;
            }
            renderWirebornList(list, Wireborns.cachedOwned(this));
        });
    }

    private void renderWirebornList(LinearLayout list, List<Wireborns.Item> items) {
        if (list == null) {
            return;
        }
        list.removeAllViews();
        final TextView empty = findViewById(R.id.wirebornEmpty);
        if (items == null || items.isEmpty()) {
            if (empty != null) {
                empty.setVisibility(View.VISIBLE);
            }
            return;
        }
        if (empty != null) {
            empty.setVisibility(View.GONE);
        }
        for (final Wireborns.Item item : items) {
            View row = getLayoutInflater().inflate(R.layout.item_wireborn, list, false);
            ImageView avatar = row.findViewById(R.id.wirebornRowAvatar);
            TextView name = row.findViewById(R.id.wirebornRowName);
            View manage = row.findViewById(R.id.wirebornRowManage);
            final String display = TextUtils.isEmpty(item.name)
                    ? (TextUtils.isEmpty(item.account) ? item.uid : item.account) : item.name;
            if (name != null) {
                name.setText(display);
            }
            if (avatar != null) {
                UiUtils.setAvatarFromRef(avatar, item.photo, display, item.uid);
            }
            if (manage != null) {
                manage.setOnClickListener(v -> openManage(item));
            }
            row.setOnClickListener(v -> openManage(item));
            list.addView(row);
        }
    }

    /** 进入某个 wireborn 的「主页即管理页」。 */
    private void openManage(Wireborns.Item item) {
        Intent intent = new Intent(this, ProfileActivity.class);
        intent.putExtra(EXTRA_MANAGE_UID, item.uid);
        intent.putExtra(EXTRA_USER_NAME, item.name);
        intent.putExtra(EXTRA_USER_PHOTO, item.photo);
        startActivity(intent);
    }

    /** 管理态：用独立的代理会话读 wireborn 自己的 public，再渲染。 */
    private void loadManagedProfile() {
        mProxy = new ProxySession(this, mUserId);
        new Thread(() -> {
            try {
                final VxCard pub = mProxy.load();
                final String bg = pub == null ? null : pub.bg;
                runOnUiThread(() -> {
                    mProxyPub = pub;
                    bindProfileCard();
                    View header = findViewById(R.id.profileHeader);
                    if (!TextUtils.isEmpty(bg)) {
                        bgPrefs().edit().putString(keyBg(), bg).apply();
                        if (header instanceof ImageView) {
                            showBackground((ImageView) header, bg);
                        }
                    } else {
                        loadSavedBackground(header instanceof ImageView ? (ImageView) header : null);
                    }
                });
            } catch (Exception ex) {
                final String detail = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                runOnUiThread(() -> Toast.makeText(this,
                        getString(R.string.proxy_token_failed) + "：" + detail, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /** 管理态名片：先用手上的数据渲染，代理会话回来后重绑一次。 */
    private void bindManagedProfileCard() {
        final Intent intent = getIntent();
        final String fallbackName = intent == null ? null : intent.getStringExtra(EXTRA_USER_NAME);
        final String fallbackPhoto = intent == null ? null : intent.getStringExtra(EXTRA_USER_PHOTO);
        ImageView avatar = findViewById(R.id.profileAvatar);
        TextView name = findViewById(R.id.profileName);
        TextView idView = findViewById(R.id.profileId);
        TextView signature = findViewById(R.id.profileSignature);

        final String fn = mProxyPub != null && !TextUtils.isEmpty(mProxyPub.fn) ? mProxyPub.fn
                : (TextUtils.isEmpty(fallbackName) ? mUserId : fallbackName);
        if (name != null) {
            name.setText(fn);
        }
        if (avatar != null) {
            if (mProxyPub != null && mProxyPub.getPhotoRef() != null) {
                UiUtils.setAvatar(avatar, mProxyPub, mUserId, false);
            } else {
                UiUtils.setAvatarFromRef(avatar, fallbackPhoto, fn, mUserId);
            }
            avatar.setOnClickListener(v -> showAvatarSheet());
        }
        UiUtils.applyProfilePhoto(avatar, mUserId);
        renderProfileMeta(mProxyPub);
        if (signature != null) {
            signature.setText(mProxyPub == null || TextUtils.isEmpty(mProxyPub.note)
                    ? getString(R.string.profile_signature_empty) : mProxyPub.note);
        }
        if (idView != null) {
            idView.setText("ID：" + mUserId);
        }
    }

    /** 以 wireborn 身份写 public：8090 换代理 token → 独立 Tinode 实例 set desc。 */
    private void saveManagedPub(final VxCard pub, final String[] attachments, final int successRes) {
        if (mProxy == null) {
            mProxy = new ProxySession(this, mUserId);
        }
        new Thread(() -> {
            try {
                mProxy.save(pub, attachments);
                mProxyPub = pub;
                runOnUiThread(() -> Toast.makeText(this, successRes, Toast.LENGTH_SHORT).show());
            } catch (Exception ex) {
                final String detail = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                runOnUiThread(() -> Toast.makeText(this,
                        getString(R.string.profile_save_failed) + "：" + detail, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private Tinode proxyTinode() throws Exception {
        if (mProxy == null) {
            mProxy = new ProxySession(this, mUserId);
        }
        return mProxy.tinode();
    }

    /** 访客态：向服务端要一次最新 desc，避免「另一账号看已变」时还显示旧昵称。 */
    private void refreshVisitorProfile() {
        if (TextUtils.isEmpty(mUserId)) {
            return;
        }
        try {
            final Tinode tinode = Cache.getTinode();
            Topic topic = tinode.getTopic(mUserId);
            if (topic == null) {
                topic = tinode.newTopic(mUserId, null);
            }
            final Topic target = topic;
            target.subscribe(null, target.getMetaGetBuilder().withDesc().build()).thenApply(
                    new PromisedReply.SuccessListener<ServerMessage>() {
                        @Override
                        public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                            runOnUiThread(() -> applyVisitorPub(target));
                            return null;
                        }
                    },
                    new PromisedReply.FailureListener<ServerMessage>() {
                        @Override
                        public <E extends Exception> PromisedReply<ServerMessage> onFailure(E err) {
                            return null;
                        }
                    });
        } catch (Exception ignored) {
            // 拉不到就继续用传入的旧资料
        }
    }

    @SuppressWarnings("unchecked")
    private void applyVisitorPub(Topic topic) {
        if (!(topic.getPub() instanceof VxCard)) {
            return;
        }
        VxCard pub = (VxCard) topic.getPub();
        TextView name = findViewById(R.id.profileName);
        TextView signature = findViewById(R.id.profileSignature);
        ImageView avatar = findViewById(R.id.profileAvatar);
        if (name != null && !TextUtils.isEmpty(pub.fn)) {
            name.setText(pub.fn);
        }
        if (signature != null && !TextUtils.isEmpty(pub.note)) {
            signature.setText(pub.note);
        }
        UiUtils.setAvatar(avatar, pub, mUserId, false);
        UiUtils.applyProfilePhoto(avatar, mUserId);
        renderProfileMeta(pub);
    }

    private void setupListItems() {
        int[] items = {
                R.id.itemAccountSecurity, R.id.itemNotifications,
                R.id.itemAboutJingyu, R.id.itemContactUs, R.id.itemSupportUs,
                R.id.itemSwitchAccount, R.id.itemDeleteAccount,
                R.id.itemSpecialThanks, R.id.itemTeam
        };
        for (int id : items) {
            bindPlaceholderItem(id);
        }

        TextView logout = findViewById(R.id.itemLogout);
        if (logout != null) {
            logout.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setMessage(R.string.logout_confirm)
                    .setPositiveButton(R.string.action_confirm, (dialog, which) -> UiUtils.doLogout(this))
                    .setNegativeButton(R.string.action_cancel, null)
                    .show());
        }
    }

    // 访客模式：隐藏设置 / 关于 / 致谢，以及名片卡片的编辑按钮。
    private void applyVisitorMode() {
        View edit = findViewById(R.id.editProfile);
        if (mCanEdit) {
            // 管理态：名片可编辑；设置/关于/致谢和「我的 wireborn」卡片隐藏；
            // 数据面板是系统字段，置灰不可编辑。
            if (edit != null) {
                edit.setVisibility(View.VISIBLE);
                edit.setOnClickListener(v -> showEditProfileDialog());
            }
            hideView(R.id.cardSettings);
            hideView(R.id.cardAbout);
            hideView(R.id.cardThanks);
            hideView(R.id.cardWireborn);
            View data = findViewById(R.id.cardData);
            if (data != null) {
                data.setAlpha(0.45f);
            }
            return;
        }
        if (mIsSelf) {
            if (edit != null) {
                edit.setVisibility(View.VISIBLE);
                edit.setOnClickListener(v -> showEditProfileDialog());
            }
            return;
        }

        hideView(R.id.cardSettings);
        hideView(R.id.cardAbout);
        hideView(R.id.cardThanks);
        hideView(R.id.editProfile);
        if (mIsWireborn) {
            hideView(R.id.cardWireborn);
        }
    }

    private void hideView(int id) {
        View view = findViewById(id);
        if (view != null) {
            view.setVisibility(View.GONE);
        }
    }

    private void bindPlaceholderItem(int id) {
        TextView view = findViewById(id);
        if (view == null) {
            return;
        }
        final CharSequence title = view.getText();
        view.setOnClickListener(v -> {
            Intent intent = new Intent(this, PlaceholderActivity.class);
            intent.putExtra(PlaceholderActivity.EXTRA_TITLE, title);
            startActivity(intent);
        });
    }

    private VxCard currentPub() {
        if (mCanEdit) {
            return mProxyPub;
        }
        MeTopic<VxCard> me = Cache.getTinode() == null ? null : Cache.getTinode().getMeTopic();
        return me == null ? null : me.getPub();
    }

    /** 名片第二行：性别 + 生日（存 Tinode public.gender / public.birthday）。 */
    private void renderProfileMeta(VxCard pub) {
        TextView meta = findViewById(R.id.profileMeta);
        if (meta == null) {
            return;
        }
        String gender = pub == null ? null : pub.gender;
        String label = "";
        if ("male".equals(gender)) {
            label = getString(R.string.profile_gender_male);
        } else if ("female".equals(gender)) {
            label = getString(R.string.profile_gender_female);
        }
        String birthday = pub == null || TextUtils.isEmpty(pub.birthday) ? "" : pub.birthday;
        StringBuilder sb = new StringBuilder();
        if (!TextUtils.isEmpty(label)) {
            sb.append(label);
        }
        if (!TextUtils.isEmpty(birthday)) {
            if (sb.length() > 0) {
                sb.append(" · ");
            }
            sb.append(getString(R.string.profile_birthday_prefix)).append(birthday);
        }
        meta.setText(sb.length() == 0 ? getString(R.string.profile_meta_empty) : sb.toString());
    }

    private static String birthdayText(int month, int day) {
        return String.format(Locale.CHINA, "%02d-%02d", month, day);
    }

    // 编辑昵称 / 签名 / 性别 / 生日。
    private void showEditProfileDialog() {
        View content = getLayoutInflater().inflate(R.layout.dialog_edit_profile, null);
        final EditText nameInput = content.findViewById(R.id.editName);
        final EditText signatureInput = content.findViewById(R.id.editSignature);
        final RadioGroup genderGroup = content.findViewById(R.id.editGender);
        final TextView birthdayView = content.findViewById(R.id.editBirthday);
        final TextView nameView = findViewById(R.id.profileName);
        final TextView signatureView = findViewById(R.id.profileSignature);
        final VxCard current = currentPub();
        final String[] pickedBirthday = new String[]{current == null ? null : current.birthday};

        if (nameInput != null && nameView != null) {
            nameInput.setText(nameView.getText());
            nameInput.setSelection(nameInput.length());
        }
        if (signatureInput != null && signatureView != null) {
            signatureInput.setText(signatureView.getText());
        }
        if (genderGroup != null) {
            final String gender = current == null ? null : current.gender;
            if ("male".equals(gender)) {
                genderGroup.check(R.id.editGenderMale);
            } else if ("female".equals(gender)) {
                genderGroup.check(R.id.editGenderFemale);
            } else {
                genderGroup.check(R.id.editGenderHidden);
            }
        }
        if (birthdayView != null) {
            birthdayView.setText(TextUtils.isEmpty(pickedBirthday[0])
                    ? getString(R.string.profile_birthday_unset)
                    : getString(R.string.profile_birthday_prefix) + pickedBirthday[0]);
            birthdayView.setOnClickListener(v -> {
                int month = 1;
                int day = 1;
                String cur = pickedBirthday[0];
                if (cur != null && cur.matches("\\d{2}-\\d{2}")) {
                    month = Integer.parseInt(cur.substring(0, 2));
                    day = Integer.parseInt(cur.substring(3, 5));
                }
                new DatePickerDialog(this, (view, year, m, d) -> {
                    pickedBirthday[0] = birthdayText(m + 1, d);
                    birthdayView.setText(getString(R.string.profile_birthday_prefix) + pickedBirthday[0]);
                }, 2000, Math.max(0, month - 1), day).show();
            });
        }

        new AlertDialog.Builder(this)
                .setTitle(R.string.profile_edit_title)
                .setView(content)
                .setPositiveButton(R.string.action_confirm, (dialog, which) -> {
                    final String newName = nameInput == null ? "" : nameInput.getText().toString().trim();
                    final String newSignature = signatureInput == null ? ""
                            : signatureInput.getText().toString().trim();
                    if (TextUtils.isEmpty(newName)) {
                        Toast.makeText(this, R.string.profile_nickname_empty, Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String gender = "";
                    if (genderGroup != null) {
                        int checked = genderGroup.getCheckedRadioButtonId();
                        if (checked == R.id.editGenderMale) {
                            gender = "male";
                        } else if (checked == R.id.editGenderFemale) {
                            gender = "female";
                        }
                    }
                    final String newGender = gender;
                    final String newBirthday = TextUtils.isEmpty(pickedBirthday[0]) ? "" : pickedBirthday[0];

                    if (nameView != null) {
                        nameView.setText(newName);
                    }
                    if (signatureView != null) {
                        signatureView.setText(newSignature);
                    }
                    VxCard preview = current == null ? new VxCard() : current.copy();
                    preview.fn = newName;
                    preview.note = newSignature;
                    preview.gender = TextUtils.isEmpty(newGender) ? null : newGender;
                    preview.birthday = TextUtils.isEmpty(newBirthday) ? null : newBirthday;
                    renderProfileMeta(preview);

                    if (mCanEdit) {
                        VxCard pub = mProxyPub == null ? new VxCard() : mProxyPub.copy();
                        pub.fn = newName;
                        pub.note = newSignature;
                        pub.gender = preview.gender;
                        pub.birthday = preview.birthday;
                        saveManagedPub(pub, null, R.string.profile_saved);
                    } else {
                        saveProfileToServer(newName, newSignature, newGender, newBirthday);
                    }
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    /**
     * 编辑资料写服务端：fn 是 Tinode 标准昵称字段，note 当签名用。
     * updateTopicDesc 只提交变化的字段，不会覆盖头像/背景（bg）等其它 public 字段。
     */
    private void saveProfileToServer(String name, String signature, String gender, String birthday) {
        final MeTopic<VxCard> me = Cache.getTinode() == null ? null : Cache.getTinode().getMeTopic();
        if (me == null) {
            Toast.makeText(this, R.string.profile_save_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        VxCard pub = me.getPub() == null ? new VxCard() : me.getPub().copy();
        pub.fn = name;
        pub.note = signature;
        pub.gender = TextUtils.isEmpty(gender) ? null : gender;
        pub.birthday = TextUtils.isEmpty(birthday) ? null : birthday;
        // 整份 public 提交：昵称/签名/性别/生日一次写完，头像与背景沿用 copy 出来的旧值。
        me.setDescription(pub, null, null).thenApply(
                new PromisedReply.SuccessListener<ServerMessage>() {
                    @Override
                    public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                        runOnUiThread(() -> Toast.makeText(ProfileActivity.this,
                                R.string.profile_saved, Toast.LENGTH_SHORT).show());
                        return null;
                    }
                },
                new PromisedReply.FailureListener<ServerMessage>() {
                    @Override
                    public <E extends Exception> PromisedReply<ServerMessage> onFailure(E err) {
                        runOnUiThread(() -> Toast.makeText(ProfileActivity.this,
                                R.string.profile_save_failed, Toast.LENGTH_SHORT).show());
                        return null;
                    }
                });
    }

    // 点击背景图：从底部滑出 1/5 屏高的操作面板，遮罩半透明，点遮罩关闭。
    private void showCoverSheet() {
        if (isFinishing() || isDestroyed()) {
            return;
        }

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View content = getLayoutInflater().inflate(R.layout.sheet_profile_cover, null);
        dialog.setContentView(content, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        dialog.setCanceledOnTouchOutside(true);

        View.OnClickListener notReadyYet = v -> {
            dialog.dismiss();
            Toast.makeText(this, R.string.feature_in_development, Toast.LENGTH_SHORT).show();
        };
        View upload = content.findViewById(R.id.coverUpload);
        if (upload != null) {
            upload.setOnClickListener(v -> {
                dialog.dismiss();
                if (mPickBackground != null) {
                    mPickBackground.launch("image/*");
                }
            });
        }
        View workshop = content.findViewById(R.id.coverWorkshop);
        if (workshop != null) {
            workshop.setOnClickListener(notReadyYet);
        }
        View delete = content.findViewById(R.id.coverDelete);
        if (delete != null) {
            delete.setOnClickListener(notReadyYet);
        }

        dialog.show();

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            int height = Math.max(dp(160), getResources().getDisplayMetrics().heightPixels / 5);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, height);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.dimAmount = 0.5f;
            window.setAttributes(lp);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
    }

    // 点头像：从底部滑出操作面板，只有「从设备中上传」一项（与背景图弹栏同款样式）。
    private void showAvatarSheet() {
        if (isFinishing() || isDestroyed() || (!mIsSelf && !mCanEdit)) {
            return;
        }

        final Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View content = getLayoutInflater().inflate(R.layout.sheet_profile_avatar, null);
        dialog.setContentView(content, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        dialog.setCanceledOnTouchOutside(true);

        View upload = content.findViewById(R.id.avatarUpload);
        if (upload != null) {
            upload.setOnClickListener(v -> {
                dialog.dismiss();
                if (mPickAvatar != null) {
                    mPickAvatar.launch("image/*");
                }
            });
        }

        dialog.show();

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.dimAmount = 0.5f;
            window.setAttributes(lp);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
    }

    private void loadSavedBackground(ImageView header) {
        if (header == null || TextUtils.isEmpty(mUserId)) {
            return;
        }
        String ref = bgPrefs().getString(keyBg(), null);
        if (TextUtils.isEmpty(ref)) {
            // 兼容旧版本 bug：以前把 topic 名 "me" 当 uid，本地键是 bg_me。迁移到真实 uid 键。
            String legacy = bgPrefs().getString("bg_me", null);
            if (!TextUtils.isEmpty(legacy)) {
                bgPrefs().edit().putString(keyBg(), legacy).apply();
                ref = legacy;
            }
        }
        if (!TextUtils.isEmpty(ref)) {
            showBackground(header, ref);
        } else {
            // 换设备/重装：本地没有就向 8090 拉一次。
            fetchBackgroundFromServer(header);
        }
    }

    private void showBackground(ImageView header, String ref) {
        if (header == null || TextUtils.isEmpty(ref)) {
            return;
        }
        // 全屏背景按 centerCrop 铺满，不拉伸；用原图而不是头像尺寸，避免放大糊掉。
        header.setScaleType(ImageView.ScaleType.CENTER_CROP);
        Coil.imageLoader(this).enqueue(new ImageRequest.Builder(this)
                .data(ref)
                .scale(Scale.FILL)
                .target(header)
                .build());
    }

    private SharedPreferences bgPrefs() {
        return getSharedPreferences(BG_PREFS, Context.MODE_PRIVATE);
    }

    private String keyBg() {
        return "bg_" + (mUserId == null ? "" : mUserId);
    }

    // 2026-11-02：头像流程 = 底部弹栏 → 相册 → 1:1 圆形裁剪（512×512 WebP）→ 上传 → 立即显示。
    private void uploadAvatar(Uri uri) {
        final ImageView avatar = findViewById(R.id.profileAvatar);
        new Thread(() -> {
            try {
                final byte[] data = ImageUploader.readAll(this, uri);
                Bitmap bmp = BitmapFactory.decodeByteArray(data, 0, data.length);
                if (bmp == null) {
                    throw new IllegalStateException("头像解码失败");
                }
                bmp = UtilsBitmap.scaleSquareBitmap(bmp, CropHelper.AVATAR_SIZE);
                final Bitmap shown = bmp;
                runOnUiThread(() -> {
                    if (avatar != null) {
                        avatar.setImageBitmap(shown);
                    }
                });

                final int width = shown.getWidth();
                final int height = shown.getHeight();
                // 头像副本落 8090：Tinode 文件会被媒体 GC，卸载重装后靠这份副本恢复。
                try {
                    ByteArrayOutputStream webpOut = new ByteArrayOutputStream();
                    shown.compress(Bitmap.CompressFormat.WEBP, 85, webpOut);
                    final byte[] webp = webpOut.toByteArray();
                    final String photoUid = mCanEdit ? mUserId : Cache.getTinode().getMyId();
                    if (!TextUtils.isEmpty(photoUid)) {
                        ProfilePhotoStore.invalidate(photoUid);
                        new Thread(() -> ProfilePhotoStore.upload(photoUid, webp, "image/webp")).start();
                    }
                } catch (Exception ignored) {
                    // 副本失败不影响主流程（Tinode 那份仍然有效）
                }
                if (mCanEdit) {
                    Tinode proxy = proxyTinode();
                    final String ref = ImageUploader.upload(proxy, data, "image/webp",
                            System.currentTimeMillis() + ".webp");
                    VxCard pub = mProxyPub == null ? new VxCard() : mProxyPub.copy();
                    TheCard.Photo photo = new TheCard.Photo();
                    photo.ref = ref;
                    photo.type = "webp";
                    photo.width = width;
                    photo.height = height;
                    pub.photo = photo;
                    saveManagedPub(pub, new String[]{ref}, R.string.avatar_updated);
                    return;
                }
                final String ref = ImageUploader.upload(Cache.getTinode(), data, "image/webp",
                        System.currentTimeMillis() + ".webp");
                runOnUiThread(() -> {
                    MeTopic<VxCard> me = Cache.getTinode().getMeTopic();
                    if (me != null) {
                        VxCard pub = me.getPub() == null ? new VxCard() : me.getPub().copy();
                        TheCard.Photo photo = new TheCard.Photo();
                        photo.ref = ref;
                        photo.type = "webp";
                        photo.width = width;
                        photo.height = height;
                        pub.photo = photo;
                        // 头像走 set desc + attachments：生成 filemsglinks，避免 1 小时后被媒体 GC 删。
                        me.setDescription(pub, null, new String[]{ref});
                    }
                    Toast.makeText(this, R.string.avatar_updated, Toast.LENGTH_SHORT).show();
                });
            } catch (Exception ex) {
                final String detail = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                runOnUiThread(() -> Toast.makeText(this,
                        getString(R.string.avatar_upload_failed) + "：" + detail, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    // 从相册选图 → 按当前窗口比例裁剪（锁竖屏）→ WebP → 上传 → 立即显示。
    private void uploadBackground(Uri uri) {
        final ImageView header = findViewById(R.id.profileHeader);
        if (header != null) {
            header.setScaleType(ImageView.ScaleType.CENTER_CROP);
            Coil.imageLoader(this).enqueue(new ImageRequest.Builder(this)
                    .data(uri)
                    .scale(Scale.FILL)
                    .target(header)
                    .build());
        }
        new Thread(() -> {
            try {
                final byte[] data = ImageUploader.readAll(this, uri);
                final String ref;
                if (mCanEdit) {
                    ref = ImageUploader.upload(proxyTinode(), data, "image/webp",
                            System.currentTimeMillis() + ".webp");
                } else {
                    ref = ImageUploader.upload(Cache.getTinode(), data, "image/webp",
                            System.currentTimeMillis() + ".webp");
                }
                runOnUiThread(() -> {
                    bgPrefs().edit().putString(keyBg(), ref).apply();
                    if (mCanEdit) {
                        VxCard pub = mProxyPub == null ? new VxCard() : mProxyPub.copy();
                        pub.bg = ref;
                        saveManagedPub(pub, new String[]{ref}, R.string.profile_background_updated);
                    } else {
                        linkProfileBackground(ref);
                    }
                    pushBackgroundToServer(ref);
                    if (header != null) {
                        showBackground(header, ref);
                    }
                    if (!mCanEdit) {
                        Toast.makeText(this, R.string.profile_background_updated,
                                Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (Exception ex) {
                final String detail = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                runOnUiThread(() -> Toast.makeText(this,
                        getString(R.string.profile_background_failed) + "：" + detail, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    /**
     * 把背景 ref 写进自己的 public（VxCard.bg）并带 attachments：
     * 一是生成 filemsglinks 防 GC，二是让其他端/访客也能从资料里拿到背景。
     */
    private void linkProfileBackground(String ref) {
        MeTopic<VxCard> me = Cache.getTinode().getMeTopic();
        if (me == null || TextUtils.isEmpty(ref)) {
            return;
        }
        VxCard pub = me.getPub() == null ? new VxCard() : me.getPub().copy();
        pub.bg = ref;
        me.setDescription(pub, null, new String[]{ref});
    }


    // B5: 背景 ref 写服务端（tinode-admin），只写真实 uid（"me" 是历史脏键，仅读时兼容）。
    private void pushBackgroundToServer(final String ref) {
        if (TextUtils.isEmpty(mUserId) || TextUtils.isEmpty(ref)) {
            return;
        }
        // 只写真实 uid；"me" 是历史脏键，仅读时兼容。
        new Thread(() -> postBackground(mUserId, ref)).start();
    }

    private void postBackground(String uid, String ref) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(PROFILE_BG_API).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json");
            JSONObject body = new JSONObject();
            body.put("uid", uid);
            body.put("ref", ref);
            try (OutputStream out = conn.getOutputStream()) {
                out.write(body.toString().getBytes("UTF-8"));
            }
            conn.getResponseCode();
        } catch (Exception ignored) {
            // 同步失败不影响本地使用。
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    // B5: 从服务端拉背景 ref（换设备/重装后恢复）；真实 uid 没有就退回 "me"。
    private void fetchBackgroundFromServer(final ImageView header) {
        if (TextUtils.isEmpty(mUserId)) {
            return;
        }
        final String[] keys = {mUserId, "me"};
        new Thread(() -> {
            String ref = null;
            for (String key : keys) {
                ref = fetchBackgroundRef(key);
                if (!TextUtils.isEmpty(ref)) {
                    break;
                }
            }
            if (TextUtils.isEmpty(ref)) {
                return;
            }
            final String resolved = ref;
            bgPrefs().edit().putString(keyBg(), resolved).apply();
            runOnUiThread(() -> {
                if (header != null && !isFinishing()) {
                    showBackground(header, resolved);
                }
            });
        }).start();
    }

    private String fetchBackgroundRef(String uid) {
        HttpURLConnection conn = null;
        try {
            String url = PROFILE_BG_API + "?uid=" + Uri.encode(uid);
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            if (conn.getResponseCode() != 200) {
                return null;
            }
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JSONObject json = new JSONObject(sb.toString());
            return json.isNull("ref") ? null : json.optString("ref", null);
        } catch (Exception ignored) {
            return null;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    /**
     * 保守判断：客户端目前没有可靠的 wireborn 标记，只有显式传入的 ID 前缀能说明问题。
     */
    private static boolean isWirebornId(String id) {
        return id != null && (id.startsWith("wireborn") || id.startsWith("agent:"));
    }
}
