package co.tinode.tindroid;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

/**
 * 鲸yu: 会话列表的本地偏好（置顶 / 本地未读），不写入 Tinode 服务端。
 */
final class TopicPrefs {
    private static final String PREFS = "jingyu_topic_prefs";
    private static final String KEY_PINNED = "pinned";
    private static final String KEY_UNREAD = "unread";
    private static final String KEY_HIDDEN = "hidden";

    private TopicPrefs() {
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private static Set<String> getSet(Context context, String key) {
        return new HashSet<>(prefs(context).getStringSet(key, new HashSet<String>()));
    }

    private static void putSet(Context context, String key, Set<String> value) {
        prefs(context).edit().putStringSet(key, value).apply();
    }

    static boolean isPinned(Context context, String topic) {
        return topic != null && getSet(context, KEY_PINNED).contains(topic);
    }

    static void setPinned(Context context, String topic, boolean pinned) {
        if (topic == null) {
            return;
        }
        Set<String> set = getSet(context, KEY_PINNED);
        if (pinned) {
            set.add(topic);
        } else {
            set.remove(topic);
        }
        putSet(context, KEY_PINNED, set);
    }

    static boolean isUnread(Context context, String topic) {
        return topic != null && getSet(context, KEY_UNREAD).contains(topic);
    }

    static void setUnread(Context context, String topic, boolean unread) {
        if (topic == null) {
            return;
        }
        Set<String> set = getSet(context, KEY_UNREAD);
        if (unread) {
            set.add(topic);
        } else {
            set.remove(topic);
        }
        putSet(context, KEY_UNREAD, set);
    }

    static boolean isHidden(Context context, String topic) {
        return topic != null && getSet(context, KEY_HIDDEN).contains(topic);
    }

    static void setHidden(Context context, String topic, boolean hidden) {
        if (topic == null) {
            return;
        }
        Set<String> set = getSet(context, KEY_HIDDEN);
        if (hidden) {
            set.add(topic);
        } else {
            set.remove(topic);
        }
        putSet(context, KEY_HIDDEN, set);
    }

    static Set<String> getHidden(Context context) {
        return getSet(context, KEY_HIDDEN);
    }
}
