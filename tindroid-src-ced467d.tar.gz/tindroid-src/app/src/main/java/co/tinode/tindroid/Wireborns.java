package co.tinode.tindroid;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 鲸yu: wireborn（数字生命）列表。启动/进主页时从 8090 拉取并本地缓存。
 *
 * · 公开列表（不带 token）：所有 wireborn 的 uid，用于识别「对方是不是数字生命」；
 * · 自己拥有的列表（带 Tinode token）：按 owner 过滤，带昵称/头像，用于
 *   「我的数字生命」卡片。
 */
final class Wireborns {
    private static final String TAG = "Wireborns";
    private static final String BASE = "http://8.138.57.26:8090";
    private static final String PREFS = "jingyu_wireborns";
    private static final long CACHE_TTL_MS = 10 * 60 * 1000L;

    private static long sLastFetch;

    private Wireborns() {
    }

    /** 卡片里的一项：uid + 昵称 + 头像 ref。 */
    static final class Item {
        final String uid;
        final String account;
        final String name;
        final String photo;

        Item(String uid, String account, String name, String photo) {
            this.uid = uid;
            this.account = account;
            this.name = name;
            this.photo = photo;
        }
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static Set<String> cached(Context context) {
        return new HashSet<>(prefs(context).getStringSet("uids", new HashSet<String>()));
    }

    static void warmUp(Context context) {
        maybeRefresh(context);
    }

    static boolean isWireborn(Context context, String uid) {
        if (uid == null || uid.isEmpty()) {
            return false;
        }
        boolean hit = cached(context).contains(uid);
        maybeRefresh(context);
        return hit;
    }

    private static synchronized void maybeRefresh(Context context) {
        long now = System.currentTimeMillis();
        if (now - sLastFetch < CACHE_TTL_MS) {
            return;
        }
        sLastFetch = now;
        final Context app = context.getApplicationContext();
        new Thread(() -> fetchAndCache(app)).start();
    }

    private static void fetchAndCache(Context context) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(BASE + "/wireborns").openConnection();
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);
            conn.setRequestMethod("GET");
            if (conn.getResponseCode() != 200) {
                return;
            }
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(
                    new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            JSONObject json = new JSONObject(sb.toString());
            JSONArray arr = json.optJSONArray("wireborns");
            Set<String> uids = new HashSet<>();
            if (arr != null) {
                for (int i = 0; i < arr.length(); i++) {
                    String uid = arr.optString(i, null);
                    if (uid != null && !uid.isEmpty()) {
                        uids.add(uid);
                    }
                }
            }
            prefs(context).edit().putStringSet("uids", uids).apply();
        } catch (Exception ex) {
            Log.w(TAG, "fetch wireborns failed", ex);
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    // ------------------------------------------------------------ 我拥有的 wireborn

    /** 本地缓存的「我的数字生命」列表（网络回来前先渲染这一份）。 */
    static List<Item> cachedOwned(Context context) {
        List<Item> out = new ArrayList<>();
        String raw = prefs(context).getString("owned", "");
        if (raw == null || raw.isEmpty()) {
            return out;
        }
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) {
                    continue;
                }
                String uid = o.optString("uid", "");
                if (!uid.isEmpty()) {
                    out.add(new Item(uid, o.optString("account", ""),
                            o.optString("fn", ""), o.optString("photo", "")));
                }
            }
        } catch (Exception ignored) {
            // 缓存损坏就当没有
        }
        return out;
    }

    /**
     * 拉「我拥有的 wireborn」：带当前用户 token，服务端按 owner 过滤。
     * onDone 在主线程回调（无论成功失败，失败时保持旧缓存）。
     */
    static void fetchOwned(Context context, String token, Runnable onDone) {
        if (token == null || token.isEmpty()) {
            return;
        }
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                // fresh=1：跳过 8090 的 5 分钟 public 缓存，改完头像/昵称返回即可见。
                String url = BASE + "/wireborns?token=" + URLEncoder.encode(token, "UTF-8") + "&fresh=1";
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setConnectTimeout(5000);
                conn.setReadTimeout(8000);
                conn.setRequestMethod("GET");
                try {
                    if (conn.getResponseCode() != 200) {
                        return;
                    }
                    StringBuilder sb = new StringBuilder();
                    try (BufferedReader reader = new BufferedReader(
                            new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = reader.readLine()) != null) {
                            sb.append(line);
                        }
                    }
                    JSONObject json = new JSONObject(sb.toString());
                    JSONArray arr = json.optJSONArray("wireborns");
                    if (arr != null) {
                        prefs(app).edit().putString("owned", arr.toString()).apply();
                    }
                } finally {
                    conn.disconnect();
                }
            } catch (Exception ex) {
                Log.w(TAG, "fetch owned wireborns failed", ex);
            } finally {
                if (onDone != null) {
                    new Handler(Looper.getMainLooper()).post(onDone);
                }
            }
        }).start();
    }
}
