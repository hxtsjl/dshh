package co.tinode.tindroid.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.util.AttributeSet;
import android.view.View;

/**
 * 鲸yu 启动页 Logo：黑色线条风格的鲸鱼，随加载进度用 PathMeasure 逐段“画”出来。
 */
public class WhaleDrawView extends View {
    private static final float VIEWPORT = 120f;

    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path[] mPaths = new Path[4];
    private final float[] mLengths = new float[4];
    private final Path mSegment = new Path();
    private float mTotalLength;
    private float mProgress;

    public WhaleDrawView(Context context) {
        super(context);
        init();
    }

    public WhaleDrawView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        mPaint.setColor(Color.BLACK);
        mPaint.setStyle(Paint.Style.STROKE);
        mPaint.setStrokeWidth(3.4f);
        mPaint.setStrokeCap(Paint.Cap.ROUND);
        mPaint.setStrokeJoin(Paint.Join.ROUND);

        mPaths[0] = new Path();
        mPaths[0].moveTo(34, 60);
        mPaths[0].lineTo(58, 36);
        mPaths[0].lineTo(88, 36);
        mPaths[0].lineTo(104, 60);
        mPaths[0].lineTo(88, 84);
        mPaths[0].lineTo(58, 84);
        mPaths[0].close();

        mPaths[1] = new Path();
        mPaths[1].moveTo(12, 44);
        mPaths[1].lineTo(34, 60);
        mPaths[1].lineTo(12, 76);
        mPaths[1].close();

        mPaths[2] = new Path();
        mPaths[2].moveTo(58, 36);
        mPaths[2].lineTo(68, 18);
        mPaths[2].lineTo(80, 36);
        mPaths[2].close();

        mPaths[3] = new Path();
        mPaths[3].addCircle(88, 54, 4.6f, Path.Direction.CW);

        mTotalLength = 0f;
        for (int i = 0; i < mPaths.length; i++) {
            mLengths[i] = new PathMeasure(mPaths[i], false).getLength();
            mTotalLength += mLengths[i];
        }
    }

    /** 0..1：画出的比例。 */
    public void setProgress(float progress) {
        mProgress = Math.max(0f, Math.min(1f, progress));
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (getWidth() <= 0 || getHeight() <= 0 || mTotalLength <= 0f) {
            return;
        }
        final float scaleX = getWidth() / VIEWPORT;
        final float scaleY = getHeight() / VIEWPORT;
        float budget = mTotalLength * mProgress;
        if (budget <= 0f) {
            return;
        }

        canvas.save();
        canvas.scale(scaleX, scaleY);
        for (int i = 0; i < mPaths.length && budget > 0f; i++) {
            final float length = mLengths[i];
            if (length <= 0f) {
                continue;
            }
            final float take = Math.min(length, budget);
            final PathMeasure measure = new PathMeasure(mPaths[i], false);
            mSegment.reset();
            measure.getSegment(0f, take, mSegment, true);
            canvas.drawPath(mSegment, mPaint);
            budget -= take;
        }
        canvas.restore();
    }
}
