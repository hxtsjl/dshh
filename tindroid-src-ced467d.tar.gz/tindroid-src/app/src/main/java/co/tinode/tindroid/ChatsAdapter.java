package co.tinode.tindroid;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.selection.ItemDetailsLookup;
import androidx.recyclerview.selection.ItemKeyProvider;
import androidx.recyclerview.selection.SelectionTracker;
import androidx.recyclerview.widget.RecyclerView;
import co.tinode.tindroid.db.StoredTopic;
import co.tinode.tindroid.format.PreviewFormatter;
import co.tinode.tindroid.media.VxCard;
import co.tinode.tinodesdk.ComTopic;
import co.tinode.tinodesdk.Storage;
import co.tinode.tinodesdk.Topic;
import co.tinode.tinodesdk.model.Drafty;
import co.tinode.tinodesdk.model.TheCard;

/**
 * Handling active chats, i.e. 'me' topic.
 */
public class ChatsAdapter extends RecyclerView.Adapter<ChatsAdapter.ViewHolder> {
    private static final int MAX_MESSAGE_PREVIEW_LENGTH = 60;

    private static int sColorOffline;
    private static int sColorOnline;
    private final ClickListener mClickListener;
    private List<ComTopic<VxCard>> mTopics;
    private HashMap<String, Integer> mTopicIndex;
    private SelectionTracker<String> mSelectionTracker;
    private final Filter mTopicFilter;
    private LongClickListener mLongClickListener;
    // Optional filter to find topics by name.
    private Filter mTextFilter = null;

    ChatsAdapter(Context context, ClickListener clickListener, @Nullable Filter filter) {
        super();

        mClickListener = clickListener;
        mTopicFilter = filter != null ? filter : topic -> true;

        setHasStableIds(true);
        setTextFilter(null);

        sColorOffline = ResourcesCompat.getColor(context.getResources(),
                R.color.offline, context.getTheme());
        sColorOnline = ResourcesCompat.getColor(context.getResources(),
                R.color.online, context.getTheme());
    }

    interface LongClickListener {
        void onTopicLongClick(ComTopic<VxCard> topic);
    }

    void setLongClickListener(LongClickListener listener) {
        mLongClickListener = listener;
    }

    void resetContent(Activity activity) {
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        final Collection<ComTopic<VxCard>> newTopics = Cache.getTinode().getFilteredTopics(t ->
                t.getTopicType().match(ComTopic.TopicType.USER) &&
                        mTopicFilter.filter((ComTopic) t) &&
                        mTextFilter.filter((ComTopic) t));

        final HashMap<String, Integer> newTopicIndex = new HashMap<>(newTopics.size());
        for (ComTopic t : newTopics) {
            newTopicIndex.put(t.getName(), newTopicIndex.size());
        }

        final List<ComTopic<VxCard>> newTopicList = new ArrayList<>(newTopics);
        // 置顶的会话排最前；List.sort 是稳定排序，其余保持原有顺序。
        final Context ctx = activity.getApplicationContext();
        newTopicList.sort((a, b) -> {
            boolean pa = TopicPrefs.isPinned(ctx, a.getName());
            boolean pb = TopicPrefs.isPinned(ctx, b.getName());
            if (pa != pb) {
                return pa ? -1 : 1;
            }
            return 0;
        });

        activity.runOnUiThread(() -> {
            mTopics = newTopicList;
            mTopicIndex = newTopicIndex;
            notifyDataSetChanged();
        });
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        final LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        return new ViewHolder(
                inflater.inflate(viewType, parent, false), mClickListener, viewType);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.longClickListener = mLongClickListener;
        if (holder.viewType == R.layout.contact) {
            if (mTopics.size() <= position) {
                // Looks like there is a race condition here.
                return;
            }
            ComTopic<VxCard> topic = mTopics.get(position);
            if (topic == null) {
                // This should not happen.
                return;
            }
            Storage.Message msg = Cache.getTinode().getLastMessage(topic.getName());
            holder.bind(position, topic, msg, mSelectionTracker != null &&
                    mSelectionTracker.isSelected(topic.getName()));
        }
    }

    @Override
    public long getItemId(int position) {
        if (getActualItemCount() == 0) {
            return -2;
        }
        return StoredTopic.getId(mTopics.get(position));
    }

    private String getItemKey(int position) {
        return mTopics.get(position).getName();
    }

    public int getItemPosition(String key) {
        if (mTopicIndex == null) {
            return -1;
        }
        Integer pos = mTopicIndex.get(key);
        return pos == null ? -1 : pos;
    }

    private int getActualItemCount() {
        return mTopics == null ? 0 : mTopics.size();
    }

    @Override
    public int getItemCount() {
        // If there are no contacts, the RV will show a single 'empty' item.
        int count = getActualItemCount();
        return count == 0 ? 1 : count;
    }

    @Override
    public int getItemViewType(int position) {
        if (getActualItemCount() == 0) {
            return R.layout.contact_empty;
        }
        return R.layout.contact;
    }

    void setSelectionTracker(SelectionTracker<String> selectionTracker) {
        mSelectionTracker = selectionTracker;
    }

    void setTextFilter(@Nullable String text) {
        mTextFilter = new Filter() {
            private final String mQuery = text;
            @Override
            public boolean filter(ComTopic topic) {
                if (TextUtils.isEmpty(mQuery)) {
                    return true;
                }

                ArrayList<String> hayStack = new ArrayList<>();
                TheCard pub = (TheCard) topic.getPub();
                if (pub != null) {
                    hayStack.add(pub.fn);
                    hayStack.add(pub.note);
                }
                hayStack.add(topic.getComment());
                return hayStack.stream()
                        .filter(token -> token != null && token.toLowerCase(Locale.getDefault()).contains(mQuery))
                        .findAny()
                        .orElse(null) != null;
            }
        };
    }

    interface ClickListener {
        void onClick(String topicName);
    }

    interface Filter {
        // Returns true to keep topic, false to ignore.
        boolean filter(ComTopic topic);
    }

    static class ContactDetailsLookup extends ItemDetailsLookup<String> {
        final RecyclerView mRecyclerView;

        ContactDetailsLookup(RecyclerView rv) {
            mRecyclerView = rv;
        }

        @Nullable
        @Override
        public ItemDetails<String> getItemDetails(@NonNull MotionEvent e) {
            View view = mRecyclerView.findChildViewUnder(e.getX(), e.getY());
            if (view != null) {
                ViewHolder holder = (ViewHolder) mRecyclerView.getChildViewHolder(view);
                return holder.getItemDetails();
            }
            return null;
        }
    }

    static class ContactDetails extends ItemDetailsLookup.ItemDetails<String> {
        int pos;
        String id;

        @Override
        public int getPosition() {
            return pos;
        }

        @Nullable
        @Override
        public String getSelectionKey() {
            return id;
        }
    }

    static class ContactKeyProvider extends ItemKeyProvider<String> {
        final ChatsAdapter mAdapter;

        ContactKeyProvider(ChatsAdapter adapter) {
            super(SCOPE_MAPPED);
            mAdapter = adapter;
        }

        @Nullable
        @Override
        public String getKey(int position) {
            return mAdapter.getItemKey(position);
        }

        @Override
        public int getPosition(@NonNull String key) {
            return mAdapter.getItemPosition(key);
        }
    }

    // 鲸yu: 头像点击 → 个人主页（访客模式）。
    private static void openProfile(View anchor, String profileId, String fullName, String photoRef) {
        Context context = anchor.getContext();
        if (context == null) {
            return;
        }
        Intent intent = new Intent(context, ProfileActivity.class);
        if (!TextUtils.isEmpty(profileId)) {
            intent.putExtra(ProfileActivity.EXTRA_USER_ID, profileId);
            if (!TextUtils.isEmpty(fullName)) {
                intent.putExtra(ProfileActivity.EXTRA_USER_NAME, fullName);
            }
            if (!TextUtils.isEmpty(photoRef)) {
                intent.putExtra(ProfileActivity.EXTRA_USER_PHOTO, photoRef);
            }
        }
        if (!(context instanceof Activity)) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        }
        context.startActivity(intent);
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final int viewType;
        TextView name;
        TextView unreadCount;
        TextView priv;
        TextView time;
        ImageView messageStatus;
        AppCompatImageView avatarView;
        ImageView online;
        ImageView deleted;
        ImageView channel;
        ImageView group;
        ImageView verified;
        ImageView staff;
        ImageView danger;
        ImageView muted;
        ImageView blocked;
        ImageView archived;
        View pinned;

        final ContactDetails details;
        ClickListener clickListener;
        LongClickListener longClickListener;

        ViewHolder(@NonNull View item, ClickListener cl, int viewType) {
            super(item);
            this.viewType = viewType;

            if (viewType == R.layout.contact) {
                name = item.findViewById(R.id.contactName);
                unreadCount = item.findViewById(R.id.unreadCount);
                priv = item.findViewById(R.id.contactPriv);
                time = item.findViewById(R.id.contactTime);
                messageStatus = item.findViewById(R.id.messageStatus);
                avatarView = item.findViewById(R.id.avatar);
                online = item.findViewById(R.id.online);
                deleted = item.findViewById(R.id.deleted);
                channel = item.findViewById(R.id.icon_channel);
                group = item.findViewById(R.id.icon_group);
                verified = item.findViewById(R.id.icon_verified);
                staff = item.findViewById(R.id.icon_staff);
                danger = item.findViewById(R.id.icon_danger);
                muted = item.findViewById(R.id.icon_muted);
                blocked = item.findViewById(R.id.icon_blocked);
                archived = item.findViewById(R.id.icon_archived);
                pinned = item.findViewById(R.id.pinnedChatIndicator);

                details = new ContactDetails();
                clickListener = cl;
            } else {
                details = null;
            }
        }

        ItemDetailsLookup.ItemDetails<String> getItemDetails() {
            return details;
        }

        void bind(int position, final ComTopic<VxCard> topic, Storage.Message msg, boolean selected) {
            final Context context = itemView.getContext();
            final String topicName = topic.getName();

            details.pos = position;
            details.id = topicName;

            VxCard pub = topic.getPub();
            if (pub != null && pub.fn != null) {
                name.setText(pub.fn);
                name.setTypeface(null, Typeface.NORMAL);
            } else if (topic.isSlfType()) {
                name.setText(R.string.self_topic_title);
                name.setTypeface(null, Typeface.NORMAL);
            } else {
                name.setText(R.string.placeholder_contact_title);
                name.setTypeface(null, Typeface.ITALIC);
            }
            Drafty content = (msg != null && !msg.isDeleted()) ? msg.getContent() : null;
            if (content != null) {
                if (msg.isMine()) {
                    messageStatus.setVisibility(View.VISIBLE);
                    UiUtils.setMessageStatusIcon(messageStatus, msg.getStatus(),
                            topic.msgReadCount(msg.getSeqId()), topic.msgRecvCount(msg.getSeqId()));
                } else {
                    messageStatus.setVisibility(View.GONE);
                }
                priv.setText(content.preview(MAX_MESSAGE_PREVIEW_LENGTH)
                        .format(new PreviewFormatter(priv.getContext(), priv.getTextSize())));
            } else {
                messageStatus.setVisibility(View.GONE);
                priv.setText(topic.getComment());
            }

            int unread = topic.getUnreadCount();
            // 本地「标为未读」优先展示。
            boolean localUnread = TopicPrefs.isUnread(context, topicName);
            if (unread <= 0 && localUnread) {
                unread = 1;
            }
            if (unread > 0) {
                unreadCount.setText(unread > 99 ? "99+" : String.valueOf(unread));
                unreadCount.setVisibility(View.VISIBLE);
                // Unread conversations use a bold title.
                name.setTypeface(Typeface.create(name.getTypeface(), Typeface.BOLD));
            } else {
                unreadCount.setVisibility(View.GONE);
            }

            // Timestamp on the right: HH:mm today, MM-dd this year, yyyy-MM-dd otherwise.
            if (time != null) {
                Date touched = topic.getTouched();
                if (touched != null) {
                    time.setText(formatChatTime(touched));
                    time.setVisibility(View.VISIBLE);
                } else {
                    time.setVisibility(View.GONE);
                }
            }

            UiUtils.setAvatar(avatarView, pub, topicName, topic.isDeleted());

            // 鲸yu: 长按会话弹出「隐藏 / 标为未读 / 设为置顶」。
            itemView.setOnLongClickListener(v -> {
                if (longClickListener != null && !topic.isDeleted()) {
                    longClickListener.onTopicLongClick(topic);
                    return true;
                }
                return false;
            });

            // 鲸yu: 会话列表里点头像进入对方（人类或 wireborn）的个人主页。
            if (avatarView != null) {
                if (Topic.isP2PType(topicName)) {
                    final String peerId = topicName;
                    final String peerName = pub == null ? null : pub.fn;
                    final String peerPhoto = pub == null ? null : pub.getPhotoRef();
                    avatarView.setOnClickListener(v -> openProfile(v, peerId, peerName, peerPhoto));
                } else {
                    avatarView.setOnClickListener(null);
                }
            }

            if (topic.isChannel()) {
                online.setVisibility(View.INVISIBLE);
                channel.setVisibility(View.VISIBLE);
            } else if (topic.isSlfType()) {
                online.setVisibility(View.INVISIBLE);
                channel.setVisibility(View.GONE);
            } else {
                channel.setVisibility(View.GONE);
                if (topic.isGrpType()) {
                   group.setVisibility(View.VISIBLE);
                } else {
                    group.setVisibility(View.GONE);
                }
                if (topic.isDeleted()) {
                    online.setVisibility(View.GONE);
                } else {
                    online.setVisibility(View.VISIBLE);
                    online.setColorFilter(topic.getOnline() ? sColorOnline : sColorOffline);
                }
            }

            if (topic.isDeleted()) {
                itemView.setAlpha(0.8f);
                deleted.setVisibility(View.VISIBLE);
            } else {
                deleted.setVisibility(View.GONE);
                itemView.setAlpha(1.0f);
            }

            verified.setVisibility(topic.isTrustedVerified() ? View.VISIBLE : View.GONE);
            staff.setVisibility(topic.isTrustedStaff() ? View.VISIBLE : View.GONE);
            danger.setVisibility(topic.isTrustedDanger() ? View.VISIBLE : View.GONE);

            if (topic.isSlfType()) {
                muted.setVisibility(View.GONE);
            } else {
                muted.setVisibility(topic.isMuted() ? View.VISIBLE : View.GONE);
            }
            archived.setVisibility(topic.isArchived() ? View.VISIBLE : View.GONE);
            blocked.setVisibility(!topic.isJoiner() ? View.VISIBLE : View.GONE);

            pinned.setVisibility(topic.getPinnedRank() > 0 ? View.VISIBLE : View.GONE);

            if (selected) {
                itemView.setBackgroundResource(R.drawable.contact_background);
                itemView.setOnClickListener(null);

                itemView.setActivated(true);
            } else {
                if (topic.getPinnedRank() > 0) {
                    itemView.setBackgroundResource(R.drawable.contact_background_pinned);
                } else {
                    itemView.setBackgroundResource(R.drawable.chat_item_background);
                }
                itemView.setOnClickListener(view -> clickListener.onClick(topicName));

                itemView.setActivated(false);
            }

            // Field lengths may have changed.
            itemView.invalidate();
        }
    }

    private static String formatChatTime(Date date) {
        Calendar now = Calendar.getInstance();
        Calendar then = Calendar.getInstance();
        then.setTime(date);
        if (now.get(Calendar.YEAR) == then.get(Calendar.YEAR)) {
            if (now.get(Calendar.DAY_OF_YEAR) == then.get(Calendar.DAY_OF_YEAR)) {
                return String.format(Locale.getDefault(), "%02d:%02d",
                        then.get(Calendar.HOUR_OF_DAY), then.get(Calendar.MINUTE));
            }
            return String.format(Locale.getDefault(), "%02d-%02d",
                    then.get(Calendar.MONTH) + 1, then.get(Calendar.DAY_OF_MONTH));
        }
        return String.format(Locale.getDefault(), "%04d-%02d-%02d",
                then.get(Calendar.YEAR), then.get(Calendar.MONTH) + 1, then.get(Calendar.DAY_OF_MONTH));
    }
}
