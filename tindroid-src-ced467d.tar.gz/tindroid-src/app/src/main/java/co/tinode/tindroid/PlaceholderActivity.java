package co.tinode.tindroid;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

/**
 * 通用占位页：顶部标题由调用方传入。
 */
public class PlaceholderActivity extends BaseActivity {
    public static final String EXTRA_TITLE = "extra_title";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UiUtils.setupSystemToolbar(this);
        setContentView(R.layout.activity_placeholder);
        applyEdgeToEdgeInsets(findViewById(android.R.id.content));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        CharSequence title = getIntent().getCharSequenceExtra(EXTRA_TITLE);
        if (title == null || title.length() == 0) {
            title = getString(R.string.app_name);
        }
        ActionBar bar = getSupportActionBar();
        if (bar != null) {
            bar.setDisplayHomeAsUpEnabled(true);
            bar.setTitle(title);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        TextView body = findViewById(R.id.placeholderText);
        body.setText(R.string.placeholder_under_construction);
    }
}
