package co.tinode.tindroid;

import android.util.Log;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

/**
 * 鲸yu：头像副本（8090 /profile/photo）。
 *
 * Tinode 的用户头像存在 public.photo.ref，文件本身会被媒体 GC 掉；一旦文件没了，
 * 重新装 App（本地缓存清空）就只能显示破损图标。所以每次改头像时在 8090 存一份
 * 二进制副本，渲染时优先用这份（按 uid 公开可读），失败再回退 Tinode 的 ref。
 */
final class ProfilePhotoStore {
    private static final String TAG = "ProfilePhotoStore";
    private static final String BASE = "http://8.138.57.26:8090";
    /** 探测结果缓存：避免每次渲染都打一次 HEAD。 */
    private static final Map<String, Boolean> sKnown = new HashMap<>();
    private static final Map<String, Long> sKnownAt = new HashMap<>();
    private static final long TTL_MS = 5 * 60 * 1000L;

    private ProfilePhotoStore() {
    }

    static String url(String uid) {
        return BASE + "/profile/photo?uid=" + URLEncoder.encode(uid);
    }

    static void invalidate(String uid) {
        synchronized (sKnown) {
            sKnown.remove(uid);
            sKnownAt.remove(uid);
        }
    }

    /** 后台探测 8090 上有没有这个 uid 的头像副本；回调在调用线程（非主线程）。 */
    static void checkAsync(String uid, Consumer<Boolean> callback) {
        if (uid == null || uid.isEmpty() || callback == null) {
            return;
        }
        synchronized (sKnown) {
            Boolean known = sKnown.get(uid);
            Long at = sKnownAt.get(uid);
            if (known != null && at != null && System.currentTimeMillis() - at < TTL_MS) {
                callback.accept(known);
                return;
            }
        }
        new Thread(() -> {
            boolean ok = probe(uid);
            synchronized (sKnown) {
                sKnown.put(uid, ok);
                sKnownAt.put(uid, System.currentTimeMillis());
            }
            callback.accept(ok);
        }).start();
    }

    private static boolean probe(String uid) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url(uid)).openConnection();
            conn.setRequestMethod("HEAD");
            conn.setConnectTimeout(4000);
            conn.setReadTimeout(4000);
            return conn.getResponseCode() == 200;
        } catch (Exception ex) {
            Log.w(TAG, "probe failed", ex);
            return false;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }

    /** 上传头像副本（webp/png 字节）。阻塞调用，必须在后台线程执行。 */
    static boolean upload(String uid, byte[] data, String mime) {
        if (uid == null || uid.isEmpty() || data == null || data.length == 0) {
            return false;
        }
        final String boundary = "----jingyu" + System.currentTimeMillis();
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(BASE + "/profile/photo").openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(20000);
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
            try (OutputStream out = conn.getOutputStream()) {
                out.write(("--" + boundary + "\r\n"
                        + "Content-Disposition: form-data; name=\"uid\"\r\n\r\n"
                        + uid + "\r\n").getBytes(StandardCharsets.UTF_8));
                out.write(("--" + boundary + "\r\n"
                        + "Content-Disposition: form-data; name=\"photo\"; filename=\"avatar.webp\"\r\n"
                        + "Content-Type: " + (mime == null ? "image/webp" : mime) + "\r\n\r\n")
                        .getBytes(StandardCharsets.UTF_8));
                out.write(data);
                out.write(("\r\n--" + boundary + "--\r\n").getBytes(StandardCharsets.UTF_8));
            }
            boolean ok = conn.getResponseCode() == 200;
            invalidate(uid);
            return ok;
        } catch (Exception ex) {
            Log.w(TAG, "upload profile photo failed", ex);
            return false;
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
