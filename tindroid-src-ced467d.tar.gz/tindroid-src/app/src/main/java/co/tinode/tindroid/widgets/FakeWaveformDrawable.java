package co.tinode.tindroid.widgets;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;

/**
 * 鲸yu 语音假波形：随机起伏的竖条，随播放进度由灰变蓝。
 *
 * 语音消息在 App 里是由 TextView 的 ImageSpan 渲染的（不是独立 View 树），
 * 所以这里做成 Drawable，接口与原来的 WaveDrawable 对齐（setDuration / seekTo /
 * start / stop / reset / setOnCompletionListener），方便嵌进同一套排版逻辑。
 */
public class FakeWaveformDrawable extends Drawable {
    private static final int BAR_COUNT = 40;

    private final Paint mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float mDensity;
    private final int mIdleColor;
    private final int mActiveColor;
    private final float[] mHeights = new float[BAR_COUNT];
    private final RectF mBar = new RectF();

    private float mProgress = 0f;
    private int mDurationMs = 0;
    private ValueAnimator mAnimator;
    private Runnable mOnCompletion;

    public FakeWaveformDrawable(Resources res, int idleColor, int activeColor) {
        mDensity = res.getDisplayMetrics().density;
        mIdleColor = idleColor;
        mActiveColor = activeColor;
        // 固定伪随机：同一条消息每次绘制形状一致
        long seed = 0x9E3779B97F4A7C15L;
        for (int i = 0; i < BAR_COUNT; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            int value = (int) ((seed >>> 33) & 0x7FFFFFFF);
            mHeights[i] = 0.22f + (value % 1000) / 1000f * 0.78f;
        }
    }

    public void setDuration(int durationMs) {
        mDurationMs = Math.max(0, durationMs);
    }

    /** 0..1，点击波形时按点击位置定位。 */
    public void seekTo(float progress) {
        mProgress = clamp(progress);
        invalidateSelf();
    }

    public void start() {
        stop();
        if (mProgress >= 1f) {
            mProgress = 0f;
        }
        final float from = mProgress;
        final float remain = 1f - from;
        final int duration = mDurationMs > 0 ? (int) (mDurationMs * remain) : 3000;
        mAnimator = ValueAnimator.ofFloat(from, 1f);
        mAnimator.setDuration(Math.max(220, duration));
        mAnimator.addUpdateListener(animator -> {
            mProgress = (float) animator.getAnimatedValue();
            invalidateSelf();
        });
        mAnimator.addListener(new AnimatorListenerAdapter() {
            private boolean canceled;

            @Override
            public void onAnimationCancel(Animator animation) {
                canceled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (canceled) {
                    return;
                }
                mProgress = 1f;
                invalidateSelf();
                if (mOnCompletion != null) {
                    mOnCompletion.run();
                }
            }
        });
        mAnimator.start();
    }

    public void stop() {
        if (mAnimator != null) {
            mAnimator.cancel();
            mAnimator = null;
        }
    }

    public void reset() {
        stop();
        mProgress = 0f;
        invalidateSelf();
    }

    public void setOnCompletionListener(Runnable listener) {
        mOnCompletion = listener;
    }

    private static float clamp(float value) {
        return value < 0f ? 0f : (value > 1f ? 1f : value);
    }

    @Override
    public void draw(Canvas canvas) {
        final Rect bounds = getBounds();
        if (bounds.width() <= 0 || bounds.height() <= 0) {
            return;
        }
        final float gap = 2f * mDensity;
        final float barWidth = 2f * mDensity;
        final int count = Math.max(8, Math.min(BAR_COUNT,
                (int) ((bounds.width() + gap) / (barWidth + gap))));
        final float bottom = bounds.top + bounds.height() * 0.92f;
        final float maxBarHeight = bounds.height() * 0.92f;
        final float radius = barWidth / 2f;
        float x = bounds.left;
        for (int i = 0; i < count; i++) {
            final float barHeight = maxBarHeight * mHeights[i % BAR_COUNT];
            mBar.set(x, bottom - barHeight, x + barWidth, bottom);
            mPaint.setColor((i + 1f) / count <= mProgress ? mActiveColor : mIdleColor);
            canvas.drawRoundRect(mBar, radius, radius, mPaint);
            x += barWidth + gap;
        }
    }

    @Override
    public void setAlpha(int alpha) {
        mPaint.setAlpha(alpha);
    }

    @Override
    public void setColorFilter(ColorFilter colorFilter) {
        mPaint.setColorFilter(colorFilter);
    }

    @Override
    public int getOpacity() {
        return PixelFormat.TRANSLUCENT;
    }
}
