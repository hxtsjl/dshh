package co.tinode.tindroid;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

/**
 * 鲸yu「社区」Tab：动态 / 创意工坊 / 论坛（先跳占位页）。
 */
public class CommunityFragment extends Fragment {
    public static final String TAG = "community";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_community, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        AppCompatActivity activity = (AppCompatActivity) requireActivity();
        ActionBar bar = activity.getSupportActionBar();
        if (bar != null) {
            bar.setDisplayHomeAsUpEnabled(false);
            bar.setDisplayShowTitleEnabled(true);
            bar.setTitle(R.string.tab_community);
        }

        bind(view, R.id.communityDynamic);
        bind(view, R.id.communityWorkshop);
        bind(view, R.id.communityForum);
    }

    private void bind(View root, int id) {
        TextView item = root.findViewById(id);
        if (item == null) {
            return;
        }
        final CharSequence title = item.getText();
        item.setOnClickListener(v -> {
            Intent intent = new Intent(requireActivity(), PlaceholderActivity.class);
            intent.putExtra(PlaceholderActivity.EXTRA_TITLE, title);
            startActivity(intent);
        });
    }
}
