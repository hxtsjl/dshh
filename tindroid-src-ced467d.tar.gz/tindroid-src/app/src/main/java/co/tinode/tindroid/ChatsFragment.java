package co.tinode.tindroid;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.NoSuchElementException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.core.view.MenuProvider;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Lifecycle;
import androidx.recyclerview.selection.Selection;
import androidx.recyclerview.selection.SelectionTracker;
import androidx.recyclerview.selection.StorageStrategy;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import co.tinode.tindroid.media.VxCard;
import co.tinode.tindroid.widgets.CircleProgressView;
import co.tinode.tindroid.widgets.HorizontalListDivider;
import co.tinode.tinodesdk.ComTopic;
import co.tinode.tinodesdk.MeTopic;
import co.tinode.tinodesdk.NotConnectedException;
import co.tinode.tinodesdk.PromisedReply;
import co.tinode.tinodesdk.model.ServerMessage;

public class ChatsFragment extends Fragment implements ActionMode.Callback, UiUtils.ProgressIndicator, MenuProvider {
    private static final String TAG = "ChatsFragment";

    private Boolean mIsArchive;
    private Boolean mIsBanned;
    private boolean mSelectionMuted;
    private boolean mSelectionPinned;

    // "Loading..." indicator.
    private CircleProgressView mProgressView;

    private ChatsAdapter mAdapter = null;
    private SelectionTracker<String> mSelectionTracker = null;
    private ActionMode mActionMode = null;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Bundle args = getArguments();
        if (args != null) {
            mIsArchive = args.getBoolean(ChatsActivity.FRAGMENT_ARCHIVE, false);
            mIsBanned = args.getBoolean(ChatsActivity.FRAGMENT_BANNED, false);
        } else {
            mIsArchive = false;
            mIsBanned = false;
        }

        return inflater.inflate(mIsArchive ? R.layout.fragment_archive : R.layout.fragment_chats,
                container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        final AppCompatActivity activity = (AppCompatActivity) requireActivity();

        final ActionBar bar = activity.getSupportActionBar();
        if (mIsArchive || mIsBanned) {
            if (bar != null) {
                bar.setDisplayHomeAsUpEnabled(true);
                bar.setTitle(mIsArchive ? R.string.archived_chats : R.string.blocked_contacts);
                ((Toolbar) activity.findViewById(R.id.toolbar)).setNavigationOnClickListener(v ->
                        activity.getSupportFragmentManager().popBackStack());
            }
        } else {
            if (bar != null) {
                bar.setDisplayHomeAsUpEnabled(false);
                bar.setTitle(null);
                // The app label would otherwise be used as a fallback title and
                // overlap the avatar/nickname block.
                bar.setDisplayShowTitleEnabled(false);
            }
            addHomeProfile(activity);
            view.findViewById(R.id.startNewChat).setOnClickListener(view1 -> {
                Intent intent = new Intent(activity, StartChatActivity.class);
                startActivity(intent);
            });
        }

        activity.addMenuProvider(this, getViewLifecycleOwner(), Lifecycle.State.RESUMED);

        RecyclerView rv = view.findViewById(R.id.chat_list);
        rv.setLayoutManager(new LinearLayoutManager(activity));
        rv.setHasFixedSize(true);
        mAdapter = new ChatsAdapter(activity, topicName -> {
            if (mActionMode != null || mIsBanned || activity.isFinishing() || activity.isDestroyed()) {
                return;
            }
            Intent intent = new Intent(activity, MessageActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
            intent.putExtra(Const.INTENT_EXTRA_TOPIC, topicName);
            activity.startActivity(intent);
        }, t -> (t.isArchived() == mIsArchive) && (t.isJoiner() != mIsBanned)
                && !TopicPrefs.isHidden(activity, t.getName()));
        mAdapter.setLongClickListener(topic -> showTopicActions(activity, topic));
        rv.setAdapter(mAdapter);

        // Progress indicator.
        mProgressView = view.findViewById(R.id.progressCircle);

        mSelectionTracker = new SelectionTracker.Builder<>(
                "contacts-selection",
                rv,
                new ChatsAdapter.ContactKeyProvider(mAdapter),
                new ChatsAdapter.ContactDetailsLookup(rv),
                StorageStrategy.createStringStorage())
                .build();

        mSelectionTracker.onRestoreInstanceState(savedInstanceState);

        mAdapter.setSelectionTracker(mSelectionTracker);
        mSelectionTracker.addObserver(new SelectionTracker.SelectionObserver<>() {
            @Override
            public void onSelectionChanged() {
                super.onSelectionChanged();
                if (mSelectionTracker.hasSelection() && mActionMode == null) {
                    mActionMode = activity.startSupportActionMode(ChatsFragment.this);
                } else if (!mSelectionTracker.hasSelection() && mActionMode != null) {
                    mActionMode.finish();
                    mActionMode = null;
                }
                if (mActionMode != null) {
                    mActionMode.setTitle(Integer.toString(mSelectionTracker.getSelection().size()));
                }
            }

            @Override
            public void onItemStateChanged(@NonNull String topicName, boolean selected) {
                int after = mSelectionTracker.getSelection().size();
                int before = selected ? after - 1 : after + 1;
                if (after == 1) {
                    ComTopic topic = (ComTopic) Cache.getTinode().getTopic(topicName);
                    if (topic != null) {
                        mSelectionMuted = topic.isMuted();
                    }
                    mSelectionPinned = Cache.getTinode().getMeTopic().isPinned(topicName);
                }
                if (mActionMode != null) {
                    if ((before > 1) != (after > 1)) {
                        mActionMode.invalidate();
                    }
                }
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();

        Bundle bundle = getArguments();
        if (bundle != null) {
            mIsArchive = bundle.getBoolean(ChatsActivity.FRAGMENT_ARCHIVE, false);
            mIsBanned = bundle.getBoolean(ChatsActivity.FRAGMENT_BANNED, false);
        } else {
            mIsArchive = false;
            mIsBanned = false;
        }

        mAdapter.resetContent(requireActivity());
        // 头像/昵称在个人主页改过后，回到列表要立即用最新 pub 重新绑定。
        updateHomeProfile();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);

        if (mSelectionTracker != null) {
            mSelectionTracker.onSaveInstanceState(outState);
        }
    }

    @Override
    public void onCreateMenu(@NonNull Menu menu, @NonNull MenuInflater menuInflater) {
        menu.clear();

        if (!mIsBanned) {
            menuInflater.inflate(R.menu.menu_chats, menu);
            menu.setGroupVisible(R.id.not_archive, !mIsArchive);
        }
    }

    /**
     * This menu is shown when no items are selected
     */
    @Override
    public boolean onMenuItemSelected(@NonNull MenuItem menuItem) {
        final ChatsActivity activity = (ChatsActivity) getActivity();
        if (activity == null) {
            return true;
        }
        int id = menuItem.getItemId();
        if (id == R.id.action_show_archive) {
            activity.showFragment(ChatsActivity.FRAGMENT_ARCHIVE, null);
            return true;
        } else if (id == R.id.action_settings) {
            activity.showFragment(ChatsActivity.FRAGMENT_ACCOUNT_INFO, null);
            return true;
        } else if (id == R.id.action_hidden_topics) {
            showHiddenTopics(activity);
            return true;
        } else if (id == R.id.action_offline) {
            Cache.getTinode().reconnectNow(true, false, false);
        }
        return false;
    }

    @Override
    public boolean onCreateActionMode(ActionMode mode, Menu menu) {
        mode.getMenuInflater().inflate(R.menu.menu_chats_selected, menu);
        return true;
    }

    @Override
    public void onDestroyActionMode(ActionMode mode) {
        mSelectionTracker.clearSelection();
    }

    @Override
    public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
        final Selection<String> selection = mSelectionTracker.getSelection();

        if (mIsBanned) {
            menu.setGroupVisible(R.id.single_selection, false);
            menu.findItem(R.id.action_unblock).setVisible(selection.size() == 1);
            return true;
        }

        boolean deleted = false;
        if (selection.size() == 1) {
            try {
                //noinspection unchecked
                ComTopic<VxCard> topic = (ComTopic<VxCard>) Cache.getTinode().getTopic(selection.iterator().next());
                deleted = topic != null && topic.isDeleted();
            } catch (NoSuchElementException ignored) {
                // Selection cleared.
                return false;
            }
        }

        if (deleted) {
            menu.setGroupVisible(R.id.single_selection, false);
            menu.findItem(R.id.action_unblock).setVisible(false);
        } else {
            menu.setGroupVisible(R.id.single_selection, selection.size() == 1);

            if (selection.size() == 1) {
                menu.findItem(R.id.action_mute).setVisible(!mSelectionMuted);
                menu.findItem(R.id.action_unmute).setVisible(mSelectionMuted);

                menu.findItem(R.id.action_archive).setVisible(!mIsArchive);
                menu.findItem(R.id.action_unarchive).setVisible(mIsArchive);

                menu.findItem(R.id.action_pin).setVisible(!mSelectionPinned);
                menu.findItem(R.id.action_unpin).setVisible(mSelectionPinned);
            }
        }

        return true;
    }

    /**
     * This menu is shown when one or more items are selected from the list
     */
    //@Override
    @SuppressWarnings("unchecked")
    public boolean onActionItemClicked(final ActionMode mode, final MenuItem item) {
        final ChatsActivity activity = (ChatsActivity) getActivity();
        if (activity == null) {
            return false;
        }

        final Selection<String> selection = mSelectionTracker.getSelection();
        int id = item.getItemId();
        if (id == R.id.action_delete) {
            String[] topicNames = new String[selection.size()];
            int i = 0;
            for (String name : selection) {
                topicNames[i++] = name;
            }
            showDeleteTopicsConfirmationDialog(topicNames);
            // Close CAB
            mode.finish();
            return true;
        } else if (id == R.id.action_mute || id == R.id.action_unmute) {
            // Muting is possible regardless of subscription status.
            if (!selection.isEmpty()) {
                final ComTopic<VxCard> topic =
                        (ComTopic<VxCard>) Cache.getTinode().getTopic(selection.iterator().next());
                topic.updateMuted(!topic.isMuted())
                        .thenApply(new PromisedReply.SuccessListener<>() {
                            @Override
                            public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                                notifyItemChanged(topic.getName());
                                return null;
                            }
                        })
                        .thenCatch(new PromisedReply.FailureListener<>() {
                            @Override
                            public PromisedReply<ServerMessage> onFailure(final Exception err) {
                                activity.runOnUiThread(() -> {
                                    Toast.makeText(activity, R.string.action_failed, Toast.LENGTH_SHORT).show();
                                    Log.w(TAG, "Muting failed", err);
                                });
                                return null;
                            }
                        });
            }
            mode.finish();
            return true;
        } else if (id == R.id.action_archive || id == R.id.action_unarchive) {
            // Archiving is possible regardless of subscription status.
            final ComTopic<VxCard> topic =
                    (ComTopic<VxCard>) Cache.getTinode().getTopic(selection.iterator().next());
            topic.updateArchived(!topic.isArchived())
                    .thenApply(new PromisedReply.SuccessListener<>() {
                        @Override
                        public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                            mAdapter.resetContent(activity);
                            return null;
                        }
                    })
                    .thenCatch(new PromisedReply.FailureListener<>() {
                        @Override
                        public PromisedReply<ServerMessage> onFailure(final Exception err) {
                            activity.runOnUiThread(() -> {
                                Toast.makeText(activity, R.string.action_failed, Toast.LENGTH_SHORT).show();
                                Log.w(TAG, "Archiving failed", err);
                            });
                            return null;
                        }
                    });

            mode.finish();
            return true;
        } else if (id == R.id.action_pin || id == R.id.action_unpin) {
            final String topicName = selection.iterator().next();
            final MeTopic me = Cache.getTinode().getMeTopic();
            me.pinTopic(topicName, id == R.id.action_pin)
                    .thenApply(new PromisedReply.SuccessListener<ServerMessage>() {
                        @Override
                        public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                            // Must use datasetChanged instead of notifyItemChanged
                            // because pinning changes order of items.
                            datasetChanged();
                            return null;
                        }
                    })
                    .thenCatch(new PromisedReply.FailureListener<>() {
                        @Override
                        public PromisedReply<ServerMessage> onFailure(final Exception err) {
                            activity.runOnUiThread(() -> {
                                Toast.makeText(activity, R.string.action_failed, Toast.LENGTH_SHORT).show();
                                Log.w(TAG, "Pinning failed", err);
                            });
                            return null;
                        }
                    });
            mode.finish();
            return true;
        } else if (id == R.id.action_unblock) {
            final ComTopic<VxCard> topic =
                    (ComTopic<VxCard>) Cache.getTinode().getTopic(selection.iterator().next());
            topic.subscribe().thenApply(new PromisedReply.SuccessListener<>() {
                @Override
                public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                    mAdapter.resetContent(activity);
                    return null;
                }
            }).thenCatch(new PromisedReply.FailureListener<>() {
                @Override
                public PromisedReply<ServerMessage> onFailure(final Exception err) {
                    activity.runOnUiThread(() -> {
                        Toast.makeText(activity, R.string.action_failed, Toast.LENGTH_SHORT).show();
                        Log.w(TAG, "Failed to unban", err);
                    });
                    return null;
                }
            });
            topic.leave();
            mode.finish();
            return true;
        }

        Log.e(TAG, "Unknown menu action");
        return false;
    }

    // Confirmation dialog "Do you really want to do X?"
    private void showDeleteTopicsConfirmationDialog(final String[] topicNames) {
        final ChatsActivity activity = (ChatsActivity) getActivity();
        if (activity == null) {
            return;
        }

        final AlertDialog.Builder confirmBuilder = new AlertDialog.Builder(activity);
        confirmBuilder.setNegativeButton(android.R.string.cancel, null);
        confirmBuilder.setMessage(R.string.confirm_delete_multiple_topics);
        confirmBuilder.setPositiveButton(android.R.string.ok,
                (dialog, which) -> {
                    PromisedReply<ServerMessage> reply = null;
                    for (String name : topicNames) {
                        @SuppressWarnings("unchecked")
                        ComTopic<VxCard> t = (ComTopic<VxCard>) Cache.getTinode().getTopic(name);
                        try {
                            reply = t.delete(true).thenCatch(new PromisedReply.FailureListener<>() {
                                @Override
                                public PromisedReply<ServerMessage> onFailure(final Exception err) {
                                    activity.runOnUiThread(() -> {
                                        Toast.makeText(activity, R.string.action_failed, Toast.LENGTH_SHORT).show();
                                        Log.w(TAG, "Delete failed", err);
                                    });
                                    return null;
                                }
                            });
                        } catch (NotConnectedException ignored) {
                            Toast.makeText(activity, R.string.no_connection, Toast.LENGTH_SHORT).show();
                        } catch (Exception err) {
                            Toast.makeText(activity, R.string.action_failed, Toast.LENGTH_SHORT).show();
                            Log.w(TAG, "Delete failed", err);
                        }
                    }
                    // Wait for the last reply to resolve then update dataset.
                    if (reply != null) {
                        reply.thenApply(new PromisedReply.SuccessListener<>() {
                            @Override
                            public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                                datasetChanged();
                                return null;
                            }
                        });
                    }
                });
        confirmBuilder.show();
    }


    // 鲸yu B4: 已隐藏会话入口，点击一项即恢复。
    private void showHiddenTopics(AppCompatActivity activity) {
        final java.util.Set<String> hidden = TopicPrefs.getHidden(activity);
        if (hidden.isEmpty()) {
            new AlertDialog.Builder(activity)
                    .setTitle(R.string.chat_hidden_sessions)
                    .setMessage(R.string.chat_hidden_empty)
                    .setPositiveButton(R.string.action_confirm, null)
                    .show();
            return;
        }
        final java.util.List<String> names = new java.util.ArrayList<>(hidden);
        final java.util.List<String> titles = new java.util.ArrayList<>();
        for (String name : names) {
            ComTopic<VxCard> topic = (ComTopic<VxCard>) Cache.getTinode().getTopic(name);
            VxCard pub = topic == null ? null : topic.getPub();
            titles.add(pub != null && pub.fn != null ? pub.fn : name);
        }
        new AlertDialog.Builder(activity)
                .setTitle(R.string.chat_hidden_sessions)
                .setItems(titles.toArray(new String[0]), (dialog, which) -> {
                    TopicPrefs.setHidden(activity, names.get(which), false);
                    datasetChanged();
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    // 鲸yu: 长按会话的自定义底部弹窗（隐藏 / 标为未读 / 置顶）。
    private void showTopicActions(AppCompatActivity activity, ComTopic<VxCard> topic) {
        final String name = topic.getName();
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        View content = getLayoutInflater().inflate(R.layout.dialog_topic_actions, null);
        dialog.setContentView(content, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        dialog.setCanceledOnTouchOutside(true);

        final TextView pin = content.findViewById(R.id.actionPin);
        if (pin != null) {
            pin.setText(TopicPrefs.isPinned(activity, name)
                    ? R.string.chat_action_unpin : R.string.chat_action_pin);
            pin.setOnClickListener(v -> {
                TopicPrefs.setPinned(activity, name, !TopicPrefs.isPinned(activity, name));
                dialog.dismiss();
                datasetChanged();
            });
        }

        View hide = content.findViewById(R.id.actionHide);
        if (hide != null) {
            hide.setOnClickListener(v -> {
                dialog.dismiss();
                TopicPrefs.setHidden(activity, name, true);
                datasetChanged();
                Toast.makeText(activity, R.string.chat_hide_toast, Toast.LENGTH_SHORT).show();
            });
        }

        View unread = content.findViewById(R.id.actionUnread);
        if (unread != null) {
            unread.setOnClickListener(v -> {
                TopicPrefs.setUnread(activity, name, true);
                dialog.dismiss();
                datasetChanged();
            });
        }

        dialog.show();
        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            window.setGravity(Gravity.BOTTOM);
            window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.dimAmount = 0.5f;
            window.setAttributes(lp);
            window.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        }
    }

    void datasetChanged() {
        toggleProgressIndicator(false);
        mAdapter.resetContent(getActivity());
        // May be called from a websocket thread: touch views on the UI thread only.
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity != null) {
            activity.runOnUiThread(this::updateHomeProfile);
        }
    }

    // 鲸yu: the chat list toolbar shows the signed-in user (avatar + nickname) instead of a title.
    private void addHomeProfile(AppCompatActivity activity) {
        Toolbar toolbar = activity.findViewById(R.id.toolbar);
        if (toolbar == null) {
            return;
        }
        if (toolbar.findViewById(R.id.homeProfile) == null) {
            View profile = getLayoutInflater().inflate(R.layout.toolbar_home_profile, toolbar, false);
            Toolbar.LayoutParams lp = new Toolbar.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            lp.gravity = GravityCompat.START | Gravity.CENTER_VERTICAL;
            toolbar.addView(profile, lp);
        }
        // Make sure no stray title text is drawn behind the avatar/nickname block.
        toolbar.setTitle(null);
        toolbar.setSubtitle(null);
        // 点左上角头像进入个人主页
        View profile = toolbar.findViewById(R.id.homeProfile);
        if (profile != null) {
            View avatar = profile.findViewById(R.id.homeAvatar);
            if (avatar != null) {
                avatar.setOnClickListener(v -> startActivity(new Intent(activity, ProfileActivity.class)));
            }
            View name = profile.findViewById(R.id.homeName);
            if (name != null) {
                name.setOnClickListener(v -> startActivity(new Intent(activity, ProfileActivity.class)));
            }
        }
        updateHomeProfile();
    }

    private void updateHomeProfile() {
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity == null || isDetached()) {
            return;
        }
        View profile = activity.findViewById(R.id.homeProfile);
        if (profile == null) {
            return;
        }
        ImageView avatar = profile.findViewById(R.id.homeAvatar);
        TextView name = profile.findViewById(R.id.homeName);
        MeTopic<VxCard> me = Cache.getTinode() == null ? null : Cache.getTinode().getMeTopic();
        VxCard pub = me == null ? null : me.getPub();
        // getMyId() 在未完全登录时可能是 null：setAvatar 支持 null，这里不能让它 NPE。
        final String myId = Cache.getTinode() == null ? null : Cache.getTinode().getMyId();
        if (avatar != null) {
            UiUtils.setAvatar(avatar, pub, myId, false);
            // 重装后 Tinode 头像文件可能已被 GC，用 8090 的头像副本兜底。
            UiUtils.applyProfilePhoto(avatar, myId);
        }
        String fn = pub == null ? null : pub.fn;
        name.setText(TextUtils.isEmpty(fn) ? activity.getString(R.string.app_name) : fn);
    }

    @Override
    public void onDestroyView() {
        AppCompatActivity activity = (AppCompatActivity) getActivity();
        if (activity != null) {
            ActionBar bar = activity.getSupportActionBar();
            if (bar != null) {
                bar.setDisplayShowTitleEnabled(true);
            }
            Toolbar toolbar = activity.findViewById(R.id.toolbar);
            View profile = toolbar == null ? null : toolbar.findViewById(R.id.homeProfile);
            if (profile != null) {
                toolbar.removeView(profile);
            }
        }
        super.onDestroyView();
    }

    void notifyItemChanged(String topicName) {
        int position = mAdapter.getItemPosition(topicName);
        if (position >= 0) {
            mAdapter.notifyItemChanged(position);
        }
    }

    @Override
    public void toggleProgressIndicator(final boolean on) {
        Activity activity = getActivity();
        if (activity == null || activity.isFinishing() || activity.isDestroyed()) {
            return;
        }

        activity.runOnUiThread(() -> {
            if (on) {
                mProgressView.show();
            } else {
                mProgressView.hide();
            }
        });
    }
}
