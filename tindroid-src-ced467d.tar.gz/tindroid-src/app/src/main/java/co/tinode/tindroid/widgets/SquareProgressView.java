package co.tinode.tindroid.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;

/**
 * 鲸yu 启动页进度条：一行细长的黑色线框，内部由实心纯黑正方形从左向右依次出现。
 */
public class SquareProgressView extends View {
    private static final int COLOR = 0xFF111111;

    private final Paint mStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF mOutline = new RectF();
    private final RectF mSquare = new RectF();
    private float mProgress = 0f;

    public SquareProgressView(Context context) {
        super(context);
        init();
    }

    public SquareProgressView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public SquareProgressView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    private void init() {
        mStrokePaint.setColor(COLOR);
        mStrokePaint.setStyle(Paint.Style.STROKE);
        mStrokePaint.setStrokeWidth(dp(1f));
        mFillPaint.setColor(COLOR);
        mFillPaint.setStyle(Paint.Style.FILL);
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    /** 0..1 */
    public void setProgress(float progress) {
        mProgress = Math.max(0f, Math.min(1f, progress));
        invalidate();
    }

    public float getProgress() {
        return mProgress;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final float stroke = dp(1f);
        final float inset = stroke / 2f;
        mOutline.set(inset, inset, getWidth() - inset, getHeight() - inset);
        if (mOutline.width() <= 0 || mOutline.height() <= 0) {
            return;
        }
        canvas.drawRect(mOutline, mStrokePaint);

        final float pad = dp(3f);
        final float left = pad + inset;
        final float top = pad + inset;
        final float right = getWidth() - pad - inset;
        final float bottom = getHeight() - pad - inset;
        final float height = bottom - top;
        if (height <= 0 || right <= left) {
            return;
        }

        final float gap = dp(3f);
        final float size = height;
        int count = (int) Math.floor((right - left + gap) / (size + gap));
        if (count <= 0) {
            return;
        }
        final int filled = Math.round(mProgress * count);
        for (int i = 0; i < filled; i++) {
            final float x = left + i * (size + gap);
            mSquare.set(x, top, x + size, bottom);
            canvas.drawRect(mSquare, mFillPaint);
        }
    }
}
