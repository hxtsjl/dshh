package co.tinode.tindroid;

import android.content.Context;
import android.net.Uri;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import co.tinode.tinodesdk.LargeFileHelper;
import co.tinode.tinodesdk.Tinode;
import co.tinode.tinodesdk.model.ServerMessage;

/**
 * 鲸yu：图片上传到 Tinode 文件服务的公共入口。
 *
 * 注意：上传只负责把文件送到 /v0/file/u/，返回的 ref 必须再挂到 topic 的
 * set desc（attachments）或消息（extra.attachments）上，才会生成 filemsglinks，
 * 否则 1 小时后会被 Tinode 的媒体 GC 删掉。
 */
final class ImageUploader {
    private ImageUploader() {
    }

    static byte[] readAll(Context context, Uri uri) throws IOException {
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) {
                throw new IOException("无法读取图片");
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[16 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        }
    }

    /**
     * use=avatar 让文件对其他用户可读（背景图、群背景图也要跨端可见）。
     * 阻塞调用，必须在后台线程执行。
     */
    static String upload(Tinode tinode, byte[] data, String mime, String name) throws Exception {
        if (tinode == null) {
            throw new IllegalStateException("Tinode 未就绪");
        }
        LargeFileHelper helper = tinode.getLargeFileHelper();
        helper.setUploadUse("avatar");
        try (ByteArrayInputStream in = new ByteArrayInputStream(data)) {
            ServerMessage msg = helper.upload(in, name, mime, data.length, null, null);
            if (msg == null || msg.ctrl == null || msg.ctrl.code != 200) {
                throw new IllegalStateException("图片上传失败");
            }
            String ref = msg.ctrl.getStringParam("url", null);
            if (ref == null || ref.isEmpty()) {
                throw new IllegalStateException("图片上传未返回 url");
            }
            return ref;
        }
    }
}
