package co.tinode.tindroid.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.animation.OvershootInterpolator;
import android.widget.EdgeEffect;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

/**
 * 鲸yu: 用官方 EdgeEffect 驱动的「越界拉伸」。
 * <p>
 * 之前自研的 BounceTouchHelper 会给 RecyclerView 设 translationY，同时 RecyclerView 自己也在
 * 拉动 overscroll，两边抢事件导致列表抽搐。这里改成：
 * · 不注册任何 OnTouchListener，正常滚动完全交给 RecyclerView；
 * · 只通过 {@link RecyclerView.EdgeEffectFactory} 接管越界那一下的 EdgeEffect，
 * 把 onPull 的距离（带阻尼）转成整个列表的 translationY，松手 Overshoot 弹回；
 * · EdgeEffect 自己不画光晕（draw 返回 false），所以不会有系统蓝边。
 */
public class StretchRecyclerView extends RecyclerView {

    private static final float MAX_STRETCH_DP = 96f;
    private static final float DAMPING = 0.35f;
    private static final long RELEASE_DURATION = 260L;

    private final float mMaxStretch;

    public StretchRecyclerView(@NonNull Context context) {
        this(context, null);
    }

    public StretchRecyclerView(@NonNull Context context, AttributeSet attrs) {
        super(context, attrs);
        mMaxStretch = MAX_STRETCH_DP * getResources().getDisplayMetrics().density;
        setEdgeEffectFactory(new EdgeEffectFactory() {
            @NonNull
            @Override
            protected EdgeEffect createEdgeEffect(@NonNull RecyclerView view, int direction) {
                return new StretchEdgeEffect(view.getContext(), direction == DIRECTION_TOP ? -1 : 1);
            }
        });
    }

    private void applyStretch(float distance, int sign) {
        animate().cancel();
        setTranslationY(sign * Math.min(distance, mMaxStretch));
    }

    private void releaseStretch() {
        if (getTranslationY() == 0f) {
            return;
        }
        animate()
                .translationY(0f)
                .setDuration(RELEASE_DURATION)
                .setInterpolator(new OvershootInterpolator(0.9f))
                .start();
    }

    private final class StretchEdgeEffect extends EdgeEffect {
        private final int mSign;
        private float mDistance;

        StretchEdgeEffect(Context context, int sign) {
            super(context);
            mSign = sign;
        }

        @Override
        public void onPull(float deltaDistance) {
            onPull(deltaDistance, 0.5f);
        }

        @Override
        public void onPull(float deltaDistance, float displacement) {
            mDistance = Math.max(0f, mDistance + deltaDistance * DAMPING * 2f);
            applyStretch(mDistance, mSign);
        }

        @Override
        public void onRelease() {
            mDistance = 0f;
            releaseStretch();
        }

        @Override
        public void onAbsorb(int velocity) {
            mDistance = 0f;
            releaseStretch();
        }

        // 不画系统光晕，只留我们自己做的位移回弹。
        @Override
        public boolean draw(Canvas canvas) {
            return false;
        }
    }
}
