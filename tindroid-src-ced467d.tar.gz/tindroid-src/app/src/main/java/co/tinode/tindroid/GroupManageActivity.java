package co.tinode.tindroid;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.widget.Toolbar;

import com.canhub.cropper.CropImageContract;
import com.canhub.cropper.CropImageContractOptions;
import com.canhub.cropper.CropImageView;

import co.tinode.tindroid.media.VxCard;
import co.tinode.tinodesdk.ComTopic;
import co.tinode.tinodesdk.MeTopic;
import co.tinode.tinodesdk.PromisedReply;
import co.tinode.tinodesdk.model.ServerMessage;
import co.tinode.tinodesdk.model.Subscription;

/**
 * 鲸yu 群聊管理页（C1）：纯白底 + 4 张 #F5F5F5 卡片。
 * 1 群基础信息 / 2 群成员（折叠）/ 3 群聊设置 / 4 危险操作。
 */
public class GroupManageActivity extends BaseActivity {
    public static final String EXTRA_TOPIC = "extra_topic";
    public static final String EXTRA_TITLE = "extra_title";

    private static final int COLLAPSED_MEMBERS = 10;
    private static final int GRID_COLUMNS = 5;
    private static final String GROUP_PREFS = "jingyu_group_prefs";

    private final List<View> mMemberCells = new ArrayList<>();
    private String mTopicName;
    private boolean mExpanded;
    private ActivityResultLauncher<String> mPickGroupBg;
    private ActivityResultLauncher<CropImageContractOptions> mCropGroupBg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        UiUtils.setupSystemToolbar(this);
        setContentView(R.layout.activity_group_manage);
        applyEdgeToEdgeInsets(findViewById(android.R.id.content));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        ActionBar bar = getSupportActionBar();
        if (bar != null) {
            bar.setDisplayHomeAsUpEnabled(true);
            bar.setDisplayShowTitleEnabled(true);
            bar.setTitle(R.string.group_manage_title_new);
        }
        toolbar.setNavigationOnClickListener(v -> finish());

        mPickGroupBg = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null && mCropGroupBg != null) {
                mCropGroupBg.launch(CropHelper.background(this, uri, R.string.group_bg_crop_title));
            }
        });
        mCropGroupBg = registerForActivityResult(new CropImageContract(), (CropImageView.CropResult result) -> {
            if (result == null || !result.isSuccessful() || result.getUriContent() == null) {
                if (result != null && result.getError() != null) {
                    Toast.makeText(this, R.string.image_crop_failed, Toast.LENGTH_SHORT).show();
                }
                return;
            }
            uploadGroupBackground(result.getUriContent());
        });

        mTopicName = getIntent().getStringExtra(EXTRA_TOPIC);
        bindBasicInfo();
        bindMembers();
        bindSettings();
        bindDangerActions();
    }

    @SuppressWarnings("unchecked")
    private ComTopic<VxCard> topic() {
        if (TextUtils.isEmpty(mTopicName)) {
            return null;
        }
        Object topic = Cache.getTinode().getTopic(mTopicName);
        return topic instanceof ComTopic ? (ComTopic<VxCard>) topic : null;
    }

    private void bindBasicInfo() {
        ComTopic<VxCard> topic = topic();
        VxCard pub = topic == null ? null : topic.getPub();

        ImageView avatar = findViewById(R.id.groupAvatar);
        if (avatar != null) {
            UiUtils.setAvatar(avatar, pub, mTopicName, topic != null && topic.isDeleted());
        }

        TextView name = findViewById(R.id.groupName);
        if (name != null) {
            CharSequence extra = getIntent().getCharSequenceExtra(EXTRA_TITLE);
            if (!TextUtils.isEmpty(extra)) {
                name.setText(extra);
            } else if (pub != null && !TextUtils.isEmpty(pub.fn)) {
                name.setText(pub.fn);
            } else {
                name.setText(R.string.group_manage_title);
            }
        }

        TextView idView = findViewById(R.id.groupId);
        if (idView != null) {
            idView.setText(getString(R.string.group_id_format, TextUtils.isEmpty(mTopicName) ? "-" : mTopicName));
        }

        View edit = findViewById(R.id.editGroupInfo);
        if (edit != null) {
            edit.setOnClickListener(v -> openPlaceholder(getString(R.string.group_manage_edit)));
        }
    }

    @SuppressWarnings("unchecked")
    private void bindMembers() {
        ComTopic<VxCard> topic = topic();
        if (topic == null) {
            return;
        }
        final Collection<? extends Subscription<VxCard, ?>> subs = topic.getSubscriptions();
        final List<Subscription<VxCard, ?>> members = new ArrayList<>();
        if (subs != null) {
            for (Subscription<VxCard, ?> sub : subs) {
                if (sub != null && !TextUtils.isEmpty(sub.user)) {
                    members.add(sub);
                }
            }
        }

        final GridLayout grid = findViewById(R.id.membersGrid);
        final TextView title = findViewById(R.id.memberTitle);
        if (title != null) {
            title.setText(getString(R.string.group_members_count, members.size()));
        }
        if (grid == null) {
            return;
        }
        grid.removeAllViews();
        mMemberCells.clear();

        for (int i = 0; i < members.size(); i++) {
            final Subscription<VxCard, ?> sub = members.get(i);
            View cell = getLayoutInflater().inflate(R.layout.item_group_member, grid, false);
            ImageView avatar = cell.findViewById(R.id.memberAvatar);
            VxCard pub = sub.pub;
            UiUtils.setAvatar(avatar, pub, sub.user, false);
            final String name = pub != null ? pub.fn : sub.user;
            cell.setOnClickListener(v -> openProfile(sub.user, name, pub == null ? null : pub.getPhotoRef()));
            addToGrid(grid, cell, i);
            mMemberCells.add(cell);
        }

        // 群主在末尾多一个「+」邀请入口。
        if (isManager(topic)) {
            View add = getLayoutInflater().inflate(R.layout.item_group_member, grid, false);
            ImageView avatar = add.findViewById(R.id.memberAvatar);
            avatar.setImageResource(R.drawable.ic_person_add);
            avatar.setOnClickListener(v -> openPlaceholder(getString(R.string.group_invite_member)));
            addToGrid(grid, add, members.size());
            mMemberCells.add(add);
        }

        applyCollapse(members.size());

        TextView expand = findViewById(R.id.memberExpand);
        if (expand != null) {
            if (members.size() <= COLLAPSED_MEMBERS) {
                expand.setVisibility(View.GONE);
            } else {
                expand.setVisibility(View.VISIBLE);
                expand.setOnClickListener(v -> {
                    mExpanded = true;
                    applyCollapse(members.size());
                    expand.setVisibility(View.GONE);
                });
            }
        }
    }

    private void addToGrid(GridLayout grid, View cell, int index) {
        // 固定 48dp 正方形：用 column weight 会把宽度拉成列宽（非正方形 → 圆形变椭圆）。
        int size = Math.round(getResources().getDisplayMetrics().density * 48);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = size;
        lp.height = size;
        lp.columnSpec = GridLayout.spec(index % GRID_COLUMNS);
        lp.rowSpec = GridLayout.spec(index / GRID_COLUMNS);
        int margin = Math.round(getResources().getDisplayMetrics().density * 4);
        lp.setMargins(margin, margin, margin, margin);
        cell.setLayoutParams(lp);
        grid.addView(cell);
    }

    private void applyCollapse(int total) {
        for (int i = 0; i < mMemberCells.size(); i++) {
            mMemberCells.get(i).setVisibility(
                    (mExpanded || i < COLLAPSED_MEMBERS) ? View.VISIBLE : View.GONE);
        }
    }

    private void bindSettings() {
        final Switch mute = findViewById(R.id.switchMute);
        if (mute != null) {
            mute.setChecked(groupPrefs().getBoolean("mute_" + mTopicName, false));
            mute.setOnCheckedChangeListener((buttonView, isChecked) ->
                    groupPrefs().edit().putBoolean("mute_" + mTopicName, isChecked).apply());
        }

        final Switch pin = findViewById(R.id.switchPin);
        if (pin != null) {
            pin.setChecked(TopicPrefs.isPinned(this, mTopicName));
            pin.setOnCheckedChangeListener((buttonView, isChecked) ->
                    TopicPrefs.setPinned(this, mTopicName, isChecked));
        }

        View search = findViewById(R.id.rowSearch);
        if (search != null) {
            search.setOnClickListener(v -> openPlaceholder(getString(R.string.group_setting_search)));
        }
        View bg = findViewById(R.id.rowGroupBg);
        if (bg != null) {
            bg.setOnClickListener(v -> {
                // 权限双重把关：UI 先判 isManager，服务端 set desc 还会再校验 W/O。
                if (!isManager(topic())) {
                    Toast.makeText(this, R.string.group_bg_manager_only, Toast.LENGTH_SHORT).show();
                    return;
                }
                if (mPickGroupBg != null) {
                    mPickGroupBg.launch("image/*");
                }
            });
        }
    }

    // 群背景：相册 → 按窗口比例裁剪（锁竖屏）→ 上传 → 写群 topic 的 public.bg。
    private void uploadGroupBackground(Uri uri) {
        new Thread(() -> {
            try {
                final byte[] data = ImageUploader.readAll(this, uri);
                final String ref = ImageUploader.upload(Cache.getTinode(), data, "image/webp",
                        System.currentTimeMillis() + ".webp");
                runOnUiThread(() -> saveGroupBackground(ref));
            } catch (Exception ex) {
                final String detail = ex.getMessage() == null ? ex.getClass().getSimpleName() : ex.getMessage();
                runOnUiThread(() -> Toast.makeText(this,
                        getString(R.string.group_bg_failed) + "：" + detail, Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void saveGroupBackground(String ref) {
        final ComTopic<VxCard> topic = topic();
        if (topic == null) {
            Toast.makeText(this, R.string.group_bg_failed, Toast.LENGTH_SHORT).show();
            return;
        }
        VxCard pub = topic.getPub() == null ? new VxCard() : topic.getPub().copy();
        pub.bg = ref;
        // attachments 生成 filemsglinks；bg 挂在 public 里，所有成员都能读到并在聊天页渲染。
        topic.setDescription(pub, null, new String[]{ref}).thenApply(
                new PromisedReply.SuccessListener<ServerMessage>() {
                    @Override
                    public PromisedReply<ServerMessage> onSuccess(ServerMessage result) {
                        runOnUiThread(() -> Toast.makeText(GroupManageActivity.this,
                                R.string.group_bg_updated, Toast.LENGTH_SHORT).show());
                        return null;
                    }
                },
                new PromisedReply.FailureListener<ServerMessage>() {
                    @Override
                    public <E extends Exception> PromisedReply<ServerMessage> onFailure(E err) {
                        runOnUiThread(() -> Toast.makeText(GroupManageActivity.this,
                                R.string.group_bg_failed, Toast.LENGTH_SHORT).show());
                        return null;
                    }
                });
    }


    /**
     * 管理方判定：群主，或订阅里带 W/O 权限的成员（Tinode 群的 admin）。
     * 不能只看 isOwner()，否则管理员看不到「+」和危险操作。
     */
    private static boolean isManager(ComTopic<VxCard> topic) {
        if (topic == null) {
            return false;
        }
        if (topic.isOwner()) {
            return true;
        }
        try {
            // getName() 返回的是 "me"，自己的 uid 要用 getMyId()，否则管理员判定永远拿不到订阅。
            String myUid = Cache.getTinode().getMyId();
            Subscription<VxCard, ?> sub = myUid == null ? null : topic.getSubscription(myUid);
            if (sub != null && sub.acs != null) {
                String mode = sub.acs.getMode();
                if (mode != null && (mode.indexOf('O') >= 0 || mode.indexOf('W') >= 0)) {
                    return true;
                }
            }
        } catch (Exception ignored) {
            // 拿不到订阅信息时按普通成员处理。
        }
        return false;
    }

    private void bindDangerActions() {
        ComTopic<VxCard> topic = topic();
        boolean owner = topic != null && isManager(topic);

        View transfer = findViewById(R.id.rowTransferOwner);
        if (transfer != null && owner) {
            transfer.setVisibility(View.VISIBLE);
            transfer.setOnClickListener(v -> openPlaceholder(getString(R.string.group_danger_transfer)));
        }
        View dissolve = findViewById(R.id.rowDissolve);
        if (dissolve != null && owner) {
            dissolve.setVisibility(View.VISIBLE);
            dissolve.setOnClickListener(v -> openPlaceholder(getString(R.string.group_danger_dissolve)));
        }
        View leave = findViewById(R.id.rowLeave);
        if (leave != null && !owner) {
            leave.setVisibility(View.VISIBLE);
            leave.setOnClickListener(v -> Toast.makeText(this,
                    R.string.feature_in_development, Toast.LENGTH_SHORT).show());
        }
    }

    private SharedPreferences groupPrefs() {
        return getSharedPreferences(GROUP_PREFS, Context.MODE_PRIVATE);
    }

    private void openPlaceholder(CharSequence title) {
        Intent intent = new Intent(this, PlaceholderActivity.class);
        intent.putExtra(PlaceholderActivity.EXTRA_TITLE, title);
        startActivity(intent);
    }

    private void openProfile(String uid, String name, String photoRef) {
        if (TextUtils.isEmpty(uid)) {
            return;
        }
        Intent intent = new Intent(this, ProfileActivity.class);
        intent.putExtra(ProfileActivity.EXTRA_USER_ID, uid);
        if (!TextUtils.isEmpty(name)) {
            intent.putExtra(ProfileActivity.EXTRA_USER_NAME, name);
        }
        if (!TextUtils.isEmpty(photoRef)) {
            intent.putExtra(ProfileActivity.EXTRA_USER_PHOTO, photoRef);
        }
        startActivity(intent);
    }
}
