package co.tinode.tindroid;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

/**
 * 鲸yu「管理」Tab：好友申请 / 好友管理（占位）。
 */
public class ManageFragment extends Fragment {
    public static final String TAG = "manage";

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_manage, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        AppCompatActivity activity = (AppCompatActivity) requireActivity();
        ActionBar bar = activity.getSupportActionBar();
        if (bar != null) {
            bar.setDisplayHomeAsUpEnabled(false);
            bar.setDisplayShowTitleEnabled(true);
            bar.setTitle(R.string.tab_manage);
        }

        view.findViewById(R.id.manageFriendRequests).setOnClickListener(v -> {
            android.content.Intent intent = new android.content.Intent(activity, PlaceholderActivity.class);
            intent.putExtra(PlaceholderActivity.EXTRA_TITLE, getString(R.string.manage_friend_requests));
            startActivity(intent);
        });
        view.findViewById(R.id.manageFriends).setOnClickListener(v ->
                Toast.makeText(activity, R.string.manage_friends, Toast.LENGTH_SHORT).show());
    }
}
