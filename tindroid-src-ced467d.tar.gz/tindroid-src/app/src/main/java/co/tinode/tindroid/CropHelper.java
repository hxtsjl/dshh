package co.tinode.tindroid;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import com.canhub.cropper.CropImageContractOptions;
import com.canhub.cropper.CropImageOptions;
import com.canhub.cropper.CropImageView;

/**
 * 鲸yu：统一裁剪参数（android-image-cropper 4.x）。
 *
 * · 头像：1:1 + 圆形遮罩，输出 512×512 WebP；
 * · 背景（个人主页 / 群聊）：裁剪窗口锁死当前设备窗口比例（含系统栏），
 *   输出宽 1080、高按比例，WebP；聊天/主页显示时再用 centerCrop 铺满，不拉伸。
 */
final class CropHelper {
    static final int AVATAR_SIZE = 512;
    static final int BACKGROUND_WIDTH = 1080;

    private CropHelper() {
    }

    static CropImageContractOptions avatar(Context context, Uri source) {
        CropImageOptions options = base(context, R.string.crop_avatar_title);
        options.cropShape = CropImageView.CropShape.OVAL;
        options.fixAspectRatio = true;
        options.aspectRatioX = 1;
        options.aspectRatioY = 1;
        options.outputRequestWidth = AVATAR_SIZE;
        options.outputRequestHeight = AVATAR_SIZE;
        options.outputCompressQuality = 90;
        return new CropImageContractOptions(source, options);
    }

    static CropImageContractOptions background(Context context, Uri source, int titleRes) {
        final int[] size = windowSize(context);
        final int width = size[0] > 0 ? size[0] : 1080;
        final int height = size[1] > 0 ? size[1] : 2340;
        final int outHeight = Math.max(1, Math.round(BACKGROUND_WIDTH * height / (float) width));

        CropImageOptions options = base(context, titleRes);
        options.cropShape = CropImageView.CropShape.RECTANGLE;
        options.fixAspectRatio = true;
        options.aspectRatioX = width;
        options.aspectRatioY = height;
        options.outputRequestWidth = BACKGROUND_WIDTH;
        options.outputRequestHeight = outHeight;
        options.outputCompressQuality = 88;
        return new CropImageContractOptions(source, options);
    }

    private static CropImageOptions base(Context context, int titleRes) {
        CropImageOptions options = new CropImageOptions();
        options.guidelines = CropImageView.Guidelines.ON;
        options.autoZoomEnabled = true;
        // 双指缩放 + 拖动同时可用的关键开关。
        options.multiTouchEnabled = true;
        options.initialCropWindowPaddingRatio = 0f;
        options.outputCompressFormat = Bitmap.CompressFormat.WEBP;
        options.outputRequestSizeOptions = CropImageView.RequestSizeOptions.RESIZE_EXACT;
        options.activityTitle = context.getString(titleRes);
        options.cropMenuCropButtonTitle = context.getString(R.string.action_confirm);
        // 裁剪页顶栏与菜单配色：白底 + 深色文字/图标，避免「确认/取消」和顶栏同色看不见。
        final int ink = context.getColor(R.color.textPrimaryDark);
        options.toolbarColor = Color.WHITE;
        options.toolbarTitleColor = ink;
        options.toolbarBackButtonColor = ink;
        options.activityMenuIconColor = ink;
        options.activityMenuTextColor = ink;
        options.activityBackgroundColor = Color.WHITE;
        return options;
    }

    /**
     * 当前设备窗口尺寸（真实像素，含状态栏/导航栏）。背景要铺到状态栏下面，所以不能用
     * 去掉系统栏后的内容区尺寸。
     */
    static int[] windowSize(Context context) {
        WindowManager wm = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) {
            return new int[]{0, 0};
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            Rect bounds = wm.getCurrentWindowMetrics().getBounds();
            return new int[]{bounds.width(), bounds.height()};
        }
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }
}
