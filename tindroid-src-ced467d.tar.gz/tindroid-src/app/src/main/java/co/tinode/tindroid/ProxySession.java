package co.tinode.tindroid;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import android.util.Log;

import androidx.preference.PreferenceManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.OffsetDateTime;

import co.tinode.tindroid.account.Utils;
import co.tinode.tindroid.media.VxCard;
import co.tinode.tinodesdk.MeTopic;
import co.tinode.tinodesdk.Tinode;
import co.tinode.tinodesdk.model.PrivateType;

/**
 * 鲸yu：wireborn 的代理会话。
 *
 * 用当前用户自己的 Tinode token 调 8090 /auth/proxy，换到该 wireborn 的短期
 * token（约 1 小时）；再用一个独立的 Tinode 实例（独立 WS、null 存储）以
 * wireborn 身份登录，读写它自己的 me.public（昵称/头像/简介/背景）。
 * 不切换当前账号、不影响当前用户连接；密码不落客户端。
 *
 * 代理 token 过期前 2 分钟自动重新换取；保存遇到鉴权失败也会换一次重试。
 */
final class ProxySession {
    private static final String TAG = "ProxySession";
    private static final String PROXY_API = "http://8.138.57.26:8090/auth/proxy";

    private final Context mContext;
    private final String mAgentUid;
    private Tinode mTinode;
    private long mExpiresAt;
    private VxCard mPub;

    ProxySession(Context context, String agentUid) {
        mContext = context.getApplicationContext();
        mAgentUid = agentUid;
    }

    /** 读 wireborn 的 public（调用前会确保代理会话可用）。 */
    synchronized VxCard load() throws Exception {
        ensure();
        return mPub == null ? new VxCard() : mPub.copy();
    }

    /** 供上传头像/背景使用；必须在后台线程调用（会阻塞）。 */
    synchronized Tinode tinode() throws Exception {
        ensure();
        return mTinode;
    }

    /** 以 wireborn 身份写 public。attachments 用来生成 filemsglinks，防止媒体被 GC。 */
    synchronized void save(VxCard pub, String[] attachments) throws Exception {
        try {
            doSave(pub, attachments);
        } catch (Exception first) {
            Log.w(TAG, "save failed, retry with fresh proxy token", first);
            invalidate();
            ensure();
            doSave(pub, attachments);
        }
    }

    private void doSave(VxCard pub, String[] attachments) throws Exception {
        ensure();
        MeTopic<VxCard> me = mTinode.getOrCreateMeTopic();
        me.setDescription(pub, null, attachments).getResult();
        mPub = pub.copy();
    }

    private void invalidate() {
        if (mTinode != null) {
            try {
                mTinode.maybeDisconnect(false);
            } catch (Exception ignored) {
                // 连接已经断了就忽略
            }
        }
        mTinode = null;
        mExpiresAt = 0L;
    }

    synchronized void close() {
        invalidate();
    }

    private void ensure() throws Exception {
        long now = System.currentTimeMillis();
        if (mTinode != null && now < mExpiresAt - 120_000L) {
            return;
        }
        invalidate();

        final String callerToken = Cache.getTinode().getAuthToken();
        if (TextUtils.isEmpty(callerToken)) {
            throw new IllegalStateException("当前登录已失效");
        }
        JSONObject resp = postJson(PROXY_API, callerToken, mAgentUid);
        if (!resp.optBoolean("ok", false)) {
            throw new IllegalStateException(resp.optString("error", "换取代理 token 失败"));
        }
        final String token = resp.optString("token", "");
        if (TextUtils.isEmpty(token)) {
            throw new IllegalStateException("代理 token 为空");
        }
        mExpiresAt = parseExpires(resp.optString("expires_at", ""));

        Tinode tinode = new Tinode("Tindroid/" + TindroidApp.getAppVersion(), Cache.getApiKey());
        tinode.setDefaultTypeOfMetaPacket(VxCard.class, PrivateType.class);
        tinode.setMeTypeOfMetaPacket(VxCard.class);
        SharedPreferences pref = PreferenceManager.getDefaultSharedPreferences(mContext);
        String host = pref.getString(Utils.PREFS_HOST_NAME, TindroidApp.getDefaultHostName());
        boolean tls = pref.getBoolean(Utils.PREFS_USE_TLS, TindroidApp.getDefaultTLS());
        tinode.connect(host, tls, false).getResult();
        tinode.loginToken(token).getResult();

        MeTopic<VxCard> me = tinode.getOrCreateMeTopic();
        me.subscribe(null, me.getMetaGetBuilder().withDesc().withSub().build()).getResult();
        mPub = me.getPub();
        mTinode = tinode;
        Log.i(TAG, "proxy session ready agent=" + mAgentUid + " expires in "
                + ((mExpiresAt - System.currentTimeMillis()) / 1000) + "s");
    }

    private static long parseExpires(String raw) {
        try {
            return OffsetDateTime.parse(raw).toInstant().toEpochMilli();
        } catch (Exception ex) {
            // 服务端格式异常时按 50 分钟后过期处理（宁可早换，不要用到 401）。
            return System.currentTimeMillis() + 50 * 60 * 1000L;
        }
    }

    private static JSONObject postJson(String endpoint, String callerToken, String agentUid) throws Exception {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(endpoint).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(10000);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            JSONObject body = new JSONObject();
            body.put("token", callerToken);
            body.put("uid", agentUid);
            try (OutputStream out = conn.getOutputStream()) {
                out.write(body.toString().getBytes(StandardCharsets.UTF_8));
            }
            int code = conn.getResponseCode();
            StringBuilder sb = new StringBuilder();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                    code >= 400 ? conn.getErrorStream() : conn.getInputStream(), StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            }
            if (code >= 400) {
                throw new IllegalStateException("换取代理 token 失败 HTTP " + code + "：" + sb);
            }
            return new JSONObject(sb.toString());
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
        }
    }
}
